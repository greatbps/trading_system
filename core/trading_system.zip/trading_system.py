#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
trading_system/core/trading_system.py

AI Trading System 메인 클래스 - 통합 시스템 관리
"""

import sys
import asyncio
import argparse
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

# Rich UI 라이브러리
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.prompt import Prompt
    from rich.table import Table
    from rich.progress import Progress, TaskID
except ImportError as e:
    print(f"❌ Rich 라이브러리 설치 필요: pip install rich")
    sys.exit(1)

# 프로젝트 루트 경로 설정
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

# 전역 콘솔 객체
console = Console()

@dataclass
class AnalysisResult:
    """분석 결과 데이터 클래스"""
    symbol: str
    name: str
    score: float
    signals: Dict[str, Any]
    analysis_time: datetime
    strategy: str
    recommendation: str
    risk_level: str
    entry_price: Optional[float] = None
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리 변환"""
        return {
            'symbol': self.symbol,
            'name': self.name,
            'score': self.score,
            'signals': self.signals,
            'analysis_time': self.analysis_time.isoformat(),
            'strategy': self.strategy,
            'recommendation': self.recommendation,
            'risk_level': self.risk_level,
            'entry_price': self.entry_price,
            'stop_loss': self.stop_loss,
            'take_profit': self.take_profit
        }

class TradingSystem:
    """AI Trading System 메인 클래스"""
    
    def __init__(self, trading_enabled: bool = False, backtest_mode: bool = False):
        self.trading_enabled = trading_enabled
        self.backtest_mode = backtest_mode
        self.config = None
        self.logger = None
        
        # 핵심 컴포넌트들
        self.data_collector = None
        self.news_collector = None
        self.analysis_engine = None
        self.strategies = {}
        
        # 매매 관련 컴포넌트 (매매 모드일 때만)
        self.executor = None
        self.position_manager = None
        self.risk_manager = None
        
        # 알림 및 DB
        self.notifier = None
        self.db_manager = None
        
        # 메뉴 핸들러
        self.menu_handlers = None
        
        # 상태 변수
        self.is_running = False
        self.last_analysis_time = None
        self.active_positions = {}
        
        # 초기화
        self._initialize_system()
    
    def _initialize_system(self):
        """시스템 초기화"""
        try:
            # Config 로드
            from config import Config
            self.config = Config
            
            # Logger 설정
            from utils.logger import get_logger
            self.logger = get_logger("TradingSystem")
            
            # 메뉴 핸들러 초기화
            from core.menu_handlers import MenuHandlers
            self.menu_handlers = MenuHandlers(self)
            
            console.print("[green]✅ 시스템 초기화 완료[/green]")
            self.logger.info(f"🚀 트레이딩 시스템 초기화 완료")
            self.logger.info(f"   매매 모드: {'활성화' if self.trading_enabled else '비활성화'}")
            self.logger.info(f"   백테스트: {'활성화' if self.backtest_mode else '비활성화'}")
            
        except ImportError as e:
            console.print(f"[red]❌ 시스템 초기화 실패: {e}[/red]")
            console.print("[yellow]💡 필요한 모듈이 설치되어 있는지 확인하세요.[/yellow]")
            sys.exit(1)
    
    async def initialize_components(self):
        """핵심 컴포넌트 초기화"""
        try:
            console.print("[yellow]🔧 핵심 컴포넌트 초기화 중...[/yellow]")
            
            # 데이터 수집기 초기화
            from data_collectors.kis_collector import KISCollector
            from data_collectors.news_collector import NewsCollector
            
            self.data_collector = KISCollector(self.config)
            self.news_collector = NewsCollector(self.config)
            
            # KIS API 세션 초기화
            await self.data_collector.initialize()
            
            # 분석 엔진 초기화
            from analyzers.analysis_engine import AnalysisEngine
            self.analysis_engine = AnalysisEngine(self.config)
            
            # 전략 초기화
            await self._initialize_strategies()
            
            # 매매 관련 컴포넌트 (매매 모드일 때만)
            if self.trading_enabled:
                await self._initialize_trading_components()
            
            # 알림 및 DB 초기화
            await self._initialize_support_components()
            
            console.print("[green]✅ 모든 컴포넌트 초기화 완료[/green]")
            self.logger.info("✅ 모든 컴포넌트 초기화 완료")
            return True
            
        except Exception as e:
            console.print(f"[red]❌ 컴포넌트 초기화 실패: {e}[/red]")
            self.logger.error(f"❌ 컴포넌트 초기화 실패: {e}")
            return False
    
    async def _initialize_strategies(self):
        """전략 초기화"""
        try:
            from strategies.momentum_strategy import MomentumStrategy
            from strategies.breakout_strategy import BreakoutStrategy
            from strategies.eod_strategy import EODStrategy
            
            self.strategies = {
                'momentum': MomentumStrategy(self.config),
                'breakout': BreakoutStrategy(self.config),
                'eod': EODStrategy(self.config),
            }
            
            console.print("[dim]  ✓ 전략 초기화 완료[/dim]")
            
        except Exception as e:
            console.print(f"[yellow]⚠️ 전략 초기화 실패: {e}[/yellow]")
            self.strategies = {}
    
    async def _initialize_trading_components(self):
        """매매 관련 컴포넌트 초기화"""
        try:
            from trading.executor import TradingExecutor
            from trading.position_manager import PositionManager
            from trading.risk_manager import RiskManager
            
            self.executor = TradingExecutor(self.config)
            self.position_manager = PositionManager(self.config)
            self.risk_manager = RiskManager(self.config)
            
            console.print("[dim]  ✓ 매매 컴포넌트 초기화 완료[/dim]")
            
        except Exception as e:
            console.print(f"[yellow]⚠️ 매매 컴포넌트 초기화 실패: {e}[/yellow]")
    
    async def _initialize_support_components(self):
        """지원 컴포넌트 초기화"""
        try:
            from notifications.telegram_bot import TelegramNotifier
            from database.database_manager import DatabaseManager
            
            self.notifier = TelegramNotifier(self.config)
            self.db_manager = DatabaseManager(self.config)
            
            console.print("[dim]  ✓ 지원 컴포넌트 초기화 완료[/dim]")
            
        except Exception as e:
            console.print(f"[yellow]⚠️ 지원 컴포넌트 초기화 실패: {e}[/yellow]")
    
    def print_banner(self):
        """시스템 배너 출력"""
        banner_text = (
            "[bold cyan]🚀 AI Trading System v3.0[/bold cyan]\n\n"
            "📊 실시간 주식 분석 + 📰 뉴스 재료 분석\n"
            "💰 수급정보 분석 + 📈 차트패턴 분석\n"
            "🔍 5개 영역 통합 분석: 기술적 + 펀더멘털 + 뉴스 + 수급 + 패턴\n"
            "💰 리스크 관리 + 포지션 관리 + 자동 알림\n\n"
            "🎯 [bold green]가중치: 기술적(30%) + 펀더멘털(25%) + 뉴스(25%) + 수급(10%) + 패턴(10%)[/bold green]\n\n"
            f"[dim]매매 모드: {'🔴 활성화' if self.trading_enabled else '🟡 비활성화'} | "
            f"백테스트: {'🔴 활성화' if self.backtest_mode else '🟡 비활성화'}[/dim]"
        )
        
        console.print(Panel.fit(
            banner_text,
            title="AI Trading System v3.0",
            border_style="cyan"
        ))
    
    def show_main_menu(self):
        """메인 메뉴 표시"""
        menu_items = [
            ("[bold cyan]🔧 시스템 관리[/bold cyan]", [
                ("1", "시스템 테스트 및 상태 확인"),
                ("2", "설정 확인 및 변경"),
                ("3", "컴포넌트 초기화")
            ]),
            ("[bold green]📊 분석 및 매매[/bold green]", [
                ("4", "종합 분석 ([yellow]5개 영역 통합[/yellow])"),
                ("5", "특정 종목 분석"),
                ("6", "뉴스 재료 분석만 실행"),
                ("7", "수급정보 분석만 실행 ([red]NEW[/red])"),
                ("8", "차트패턴 분석만 실행 ([red]NEW[/red])"),
                ("9", "자동매매 시작 ([red]실제 거래[/red])" if self.trading_enabled else "9", "[dim]자동매매 (비활성화)[/dim]"),
                ("10", "백테스트 실행"),
                ("11", "스케줄러 시작")
            ]),
            ("[bold blue]🗄️ 데이터베이스[/bold blue]", [
                ("12", "데이터베이스 상태 확인"),
                ("13", "종목 데이터 조회"),
                ("14", "분석 결과 조회"),
                ("15", "거래 기록 조회")
            ]),
            ("[bold magenta]🛠️ 고급 기능[/bold magenta]", [
                ("16", "데이터 정리 및 최적화"),
                ("17", "로그 분석"),
                ("18", "시스템 상태 모니터링")
            ])
        ]
        
        menu_text = ""
        for category, items in menu_items:
            menu_text += f"{category}\n"
            for item in items:
                if isinstance(item, tuple) and len(item) == 2:
                    num, desc = item
                    menu_text += f"  {num}. {desc}\n"
            menu_text += "\n"
        
        menu_text += "  [bold red]0. 종료[/bold red]"
        
        console.print(Panel.fit(
            menu_text,
            title="📋 메인 메뉴 (Enhanced)",
            border_style="cyan"
        ))
    
    def get_user_choice(self) -> str:
        """사용자 선택 입력받기"""
        try:
            return Prompt.ask(
                "\n[bold yellow]메뉴를 선택하세요[/bold yellow]",
                default="0"
            ).strip()
        except KeyboardInterrupt:
            return "0"
    
    # === 핵심 분석 기능들 (기존 코드 통합) ===
    
    async def run_market_analysis(self, strategy: str = 'momentum', limit: int = 100) -> List[AnalysisResult]:
        """전체 시장 분석 실행"""
        self.logger.info(f"📊 전체 시장 분석 시작 (전략: {strategy}, 제한: {limit}개)")
        
        # 컴포넌트 초기화 확인
        if not await self._check_components():
            return []
        
        try:
            with Progress() as progress:
                task = progress.add_task("[green]시장 분석 진행 중...", total=100)
                
                # 1단계: 종목 필터링
                progress.update(task, advance=10, description="[yellow]종목 필터링 중...")
                candidates = await self.data_collector.get_filtered_stocks(limit=limit)
                self.logger.info(f"   필터링 결과: {len(candidates)}개 종목")
                
                if not candidates:
                    console.print("[yellow]⚠️ 필터링된 종목이 없습니다.[/yellow]")
                    return []
                
                # 2단계: 종합 분석
                progress.update(task, advance=20, description="[yellow]종합 분석 중...")
                results = []
                
                for i, (symbol, name) in enumerate(candidates):
                    try:
                        # 개별 종목 분석
                        result = await self.analyze_symbol(symbol, name, strategy)
                        if result and result.score >= self.config.analysis.MIN_COMPREHENSIVE_SCORE:
                            results.append(result)
                        
                        # 진행률 업데이트
                        progress.update(task, advance=60/len(candidates))
                        
                        # API 제한 방지
                        await asyncio.sleep(0.1)
                        
                    except Exception as e:
                        self.logger.warning(f"   ⚠️ {symbol} 분석 실패: {e}")
                        continue
                
                # 3단계: 결과 정렬 및 저장
                progress.update(task, advance=5, description="[yellow]결과 정렬 중...")
                results.sort(key=lambda x: x.score, reverse=True)
                
                progress.update(task, advance=3, description="[yellow]결과 저장 중...")
                await self._save_analysis_results(results)
                
                # 4단계: 알림 발송
                progress.update(task, advance=2, description="[yellow]알림 발송 중...")
                if results:
                    await self._send_analysis_notification(results[:10])
                
                progress.update(task, advance=0, description="[green]완료!")
            
            console.print(f"[green]✅ 시장 분석 완료: {len(results)}개 신호 발견[/green]")
            self.logger.info(f"✅ 시장 분석 완료: {len(results)}개 신호 발견")
            return results
            
        except Exception as e:
            console.print(f"[red]❌ 시장 분석 실패: {e}[/red]")
            self.logger.error(f"❌ 시장 분석 실패: {e}")
            return []
    
    async def analyze_symbol(self, symbol: str, name: str, strategy: str) -> Optional[AnalysisResult]:
        """개별 종목 분석 (기존 코드 유지)"""
        try:
            # 1. 기본 데이터 수집
            stock_data = await self.data_collector.get_stock_data(symbol)
            if not stock_data:
                return None
            
            # 2. 뉴스 분석
            news_data = await self.news_collector.analyze_stock_news(symbol, name)
            
            # 3. 종합 분석
            analysis_result = await self.analysis_engine.analyze_comprehensive(
                symbol=symbol,
                name=name,
                stock_data=stock_data,
                news_data=news_data,
                strategy=strategy
            )
            
            # 4. 전략별 신호 생성
            strategy_obj = self.strategies.get(strategy)
            if not strategy_obj:
                self.logger.warning(f"⚠️ 알 수 없는 전략: {strategy}")
                return None
            
            signals = await strategy_obj.generate_signals(stock_data, analysis_result)
            
            # 5. 리스크 평가
            risk_level = await self._evaluate_risk(stock_data, analysis_result)
            
            # 6. 매수/매도 가격 계산
            entry_price, stop_loss, take_profit = await self._calculate_trade_prices(
                stock_data, signals, strategy_obj
            )
            
            # 7. 결과 생성
            result = AnalysisResult(
                symbol=symbol,
                name=name,
                score=analysis_result.get('comprehensive_score', 0),
                signals=signals,
                analysis_time=datetime.now(),
                strategy=strategy,
                recommendation=self._get_recommendation(analysis_result, signals),
                risk_level=risk_level,
                entry_price=entry_price,
                stop_loss=stop_loss,
                take_profit=take_profit
            )
            
            return result
            
        except Exception as e:
            self.logger.error(f"❌ {symbol} 분석 실패: {e}")
            return None
    
    async def analyze_symbols(self, symbols: List[str], strategy: str = 'momentum') -> List[AnalysisResult]:
        """특정 종목들 분석"""
        console.print(f"[yellow]🎯 특정 종목 분석: {len(symbols)}개 (전략: {strategy})[/yellow]")
        self.logger.info(f"🎯 특정 종목 분석: {len(symbols)}개 (전략: {strategy})")
        
        # 컴포넌트 초기화 확인
        if not await self._check_components():
            return []
        
        results = []
        
        with Progress() as progress:
            task = progress.add_task("[green]종목 분석 중...", total=len(symbols))
            
            for i, symbol in enumerate(symbols):
                try:
                    progress.update(task, description=f"[yellow]{symbol} 분석 중... ({i+1}/{len(symbols)})[/yellow]")
                    
                    # 종목명 조회
                    stock_info = await self.data_collector.get_stock_info(symbol)
                    name = stock_info.get('name', symbol) if stock_info else symbol
                    
                    # 분석 실행
                    result = await self.analyze_symbol(symbol, name, strategy)
                    if result:
                        results.append(result)
                    
                    progress.update(task, advance=1)
                    await asyncio.sleep(0.1)
                    
                except Exception as e:
                    self.logger.warning(f"⚠️ {symbol} 분석 실패: {e}")
                    progress.update(task, advance=1)
                    continue
        
        # 결과 정렬
        results.sort(key=lambda x: x.score, reverse=True)
        
        console.print(f"[green]✅ 특정 종목 분석 완료: {len(results)}개 결과[/green]")
        self.logger.info(f"✅ 특정 종목 분석 완료: {len(results)}개 결과")
        return results
    
    async def run_auto_trading(self, strategy: str = 'momentum'):
        """자동매매 실행"""
        if not self.trading_enabled:
            console.print("[red]❌ 매매 모드가 비활성화되어 있습니다.[/red]")
            return
        
        console.print(f"[bold green]💰 자동매매 시작 (전략: {strategy})[/bold green]")
        self.logger.info(f"💰 자동매매 시작 (전략: {strategy})")
        self.is_running = True
        
        try:
            while self.is_running:
                # 장시간 체크
                if not self.config.is_trading_time():
                    console.print("[dim]⏰ 장시간이 아닙니다. 대기 중...[/dim]")
                    await asyncio.sleep(300)  # 5분 대기
                    continue
                
                # 1. 시장 분석
                analysis_results = await self.run_market_analysis(strategy=strategy, limit=50)
                
                # 2. 매수 신호 처리
                buy_signals = [r for r in analysis_results if r.recommendation == 'BUY']
                for signal in buy_signals[:5]:  # 최대 5개까지
                    await self._process_buy_signal(signal)
                
                # 3. 보유 포지션 관리
                await self._manage_positions()
                
                # 4. 리스크 체크
                await self._check_risk_limits()
                
                # 5. 대기
                await asyncio.sleep(180)  # 3분 대기
                
        except KeyboardInterrupt:
            console.print("[yellow]🛑 자동매매 중단 요청[/yellow]")
        except Exception as e:
            error_msg = f"자동매매 오류: {e}"
            console.print(f"[red]❌ {error_msg}[/red]")
            self.logger.error(f"❌ {error_msg}")
            if self.notifier:
                await self.notifier.send_error_message(error_msg)
        finally:
            self.is_running = False
            console.print("[bold]🏁 자동매매 종료[/bold]")
            self.logger.info("🏁 자동매매 종료")
    
    async def run_backtest(self, strategy: str, start_date: str, end_date: str, symbols: List[str] = None) -> Dict[str, Any]:
        """백테스트 실행"""
        console.print(f"[yellow]📈 백테스트 시작: {start_date} ~ {end_date} (전략: {strategy})[/yellow]")
        self.logger.info(f"📈 백테스트 시작: {start_date} ~ {end_date} (전략: {strategy})")
        
        try:
            # 백테스트 엔진 초기화
            from analyzers.backtest_engine import BacktestEngine
            backtest_engine = BacktestEngine(self.config)
            
            # 백테스트 실행
            results = await backtest_engine.run_backtest(
                strategy=strategy,
                start_date=start_date,
                end_date=end_date,
                symbols=symbols,
                initial_capital=self.config.trading.INITIAL_CAPITAL
            )
            
            # 결과 저장
            await self._save_backtest_results(results)
            
            console.print("[green]✅ 백테스트 완료[/green]")
            self.logger.info("✅ 백테스트 완료")
            return results
            
        except Exception as e:
            console.print(f"[red]❌ 백테스트 실패: {e}[/red]")
            self.logger.error(f"❌ 백테스트 실패: {e}")
            raise
    
    # === 지원 메서드들 ===
    
    async def _check_components(self) -> bool:
        """컴포넌트 초기화 상태 확인"""
        if not self.data_collector or not self.analysis_engine:
            console.print("[yellow]⚠️ 컴포넌트가 초기화되지 않았습니다. 자동 초기화 중...[/yellow]")
            return await self.initialize_components()
        return True
    
    async def _evaluate_risk(self, stock_data: Dict, analysis_result: Dict) -> str:
        """리스크 평가 (기존 코드 유지)"""
        risk_score = 0
        
        # 변동성 체크
        volatility = analysis_result.get('volatility', 0)
        if volatility > 0.1:
            risk_score += 3
        elif volatility > 0.05:
            risk_score += 2
        else:
            risk_score += 1
        
        # 거래량 체크
        volume_ratio = analysis_result.get('volume_ratio', 1)
        if volume_ratio < 0.5:
            risk_score += 2
        
        # 시가총액 체크
        market_cap = stock_data.get('market_cap', 0)
        if market_cap < 500:  # 500억 미만
            risk_score += 2
        
        # 리스크 레벨 결정
        if risk_score >= 6:
            return "HIGH"
        elif risk_score >= 4:
            return "MEDIUM"
        else:
            return "LOW"
    
    def _get_recommendation(self, analysis_result: Dict, signals: Dict) -> str:
        """추천 등급 결정 (기존 코드 유지)"""
        score = analysis_result.get('comprehensive_score', 0)
        signal_strength = signals.get('signal_strength', 0)
        
        if score >= 80 and signal_strength >= 90:
            return "STRONG_BUY"
        elif score >= 70 and signal_strength >= 75:
            return "BUY"
        elif score >= 60 and signal_strength >= 60:
            return "WEAK_BUY"
        elif score <= 40:
            return "SELL"
        else:
            return "HOLD"
    
    async def _calculate_trade_prices(self, stock_data: Dict, signals: Dict, strategy) -> tuple:
        """매매 가격 계산 (기존 코드 유지)"""
        current_price = stock_data.get('current_price', 0)
        
        # 진입가 (현재가 기준)
        entry_price = current_price
        
        # 손절가 (전략별 로직)
        stop_loss = await strategy.calculate_stop_loss(stock_data, current_price)
        
        # 익절가 (전략별 로직)
        take_profit = await strategy.calculate_take_profit(stock_data, current_price)
        
        return entry_price, stop_loss, take_profit
    
    async def _save_analysis_results(self, results: List[AnalysisResult]):
        """분석 결과 저장"""
        try:
            if self.db_manager:
                await self.db_manager.save_analysis_results(results)
        except Exception as e:
            self.logger.error(f"❌ 분석 결과 저장 실패: {e}")
    
    async def _send_analysis_notification(self, results: List[AnalysisResult]):
        """분석 결과 알림"""
        try:
            if self.notifier:
                await self.notifier.send_analysis_notification(results)
        except Exception as e:
            self.logger.error(f"❌ 분석 결과 알림 실패: {e}")
    
    async def _save_backtest_results(self, results: Dict[str, Any]):
        """백테스트 결과 저장"""
        try:
            if self.db_manager:
                await self.db_manager.save_backtest_results(results)
        except Exception as e:
            self.logger.error(f"❌ 백테스트 결과 저장 실패: {e}")
    
    # === 매매 관련 메서드들 (매매 모드일 때만 사용) ===
    
    async def _process_buy_signal(self, signal: AnalysisResult):
        """매수 신호 처리"""
        if not self.trading_enabled or not self.executor:
            return
        
        try:
            # 1. 리스크 체크
            if not await self.risk_manager.can_open_position(signal.symbol, signal.entry_price):
                self.logger.info(f"⚠️ {signal.symbol} 리스크 제한으로 매수 불가")
                return
            
            # 2. 포지션 크기 계산
            position_size = await self.position_manager.calculate_position_size(
                signal.symbol, signal.entry_price, signal.stop_loss
            )
            
            # 3. 주문 실행
            order_result = await self.executor.place_buy_order(
                symbol=signal.symbol,
                quantity=position_size,
                price=signal.entry_price
            )
            
            # 4. 포지션 등록
            if order_result['success']:
                await self.position_manager.add_position(
                    symbol=signal.symbol,
                    quantity=position_size,
                    entry_price=order_result['fill_price'],
                    stop_loss=signal.stop_loss,
                    take_profit=signal.take_profit,
                    strategy=signal.strategy
                )
                
                # 5. 알림 발송
                await self.notifier.send_buy_notification(signal, order_result)
                
                self.logger.info(f"✅ {signal.symbol} 매수 완료: {position_size}주 @ {order_result['fill_price']:,}원")
            
        except Exception as e:
            self.logger.error(f"❌ {signal.symbol} 매수 처리 실패: {e}")
    
    async def _manage_positions(self):
        """보유 포지션 관리"""
        if not self.trading_enabled or not self.position_manager:
            return
        
        try:
            positions = await self.position_manager.get_active_positions()
            
            for position in positions:
                # 1. 현재가 조회
                current_price = await self.data_collector.get_current_price(position['symbol'])
                
                # 2. 손익 계산
                pnl_ratio = (current_price - position['entry_price']) / position['entry_price']
                
                # 3. 손절/익절 체크
                should_sell = False
                sell_reason = ""
                
                if current_price <= position['stop_loss']:
                    should_sell = True
                    sell_reason = "손절"
                elif current_price >= position['take_profit']:
                    should_sell = True
                    sell_reason = "익절"
                elif await self._should_trailing_stop(position, current_price):
                    should_sell = True
                    sell_reason = "트레일링 스톱"
                
                # 4. 매도 실행
                if should_sell:
                    await self._process_sell_signal(position, current_price, sell_reason)
                
        except Exception as e:
            self.logger.error(f"❌ 포지션 관리 실패: {e}")
    
    async def _process_sell_signal(self, position: Dict, current_price: float, reason: str):
        """매도 신호 처리"""
        if not self.trading_enabled or not self.executor:
            return
        
        try:
            # 매도 주문 실행
            order_result = await self.executor.place_sell_order(
                symbol=position['symbol'],
                quantity=position['quantity'],
                price=current_price
            )
            
            if order_result['success']:
                # 포지션 종료
                await self.position_manager.close_position(position['id'])
                
                # 알림 발송
                if self.notifier:
                    await self.notifier.send_sell_notification(position, order_result, reason)
                
                self.logger.info(f"✅ {position['symbol']} 매도 완료 ({reason}): {order_result['fill_price']:,}원")
            
        except Exception as e:
            self.logger.error(f"❌ {position['symbol']} 매도 처리 실패: {e}")
    
    async def _should_trailing_stop(self, position: Dict, current_price: float) -> bool:
        """트레일링 스톱 조건 체크"""
        # 간단한 트레일링 스톱 로직 (3% 하락 시)
        if not position.get('highest_price'):
            return False
        
        trailing_ratio = 0.03  # 3%
        trailing_price = position['highest_price'] * (1 - trailing_ratio)
        
        return current_price <= trailing_price
    
    async def _check_risk_limits(self):
        """리스크 한도 체크"""
        if not self.trading_enabled or not self.risk_manager:
            return
        
        try:
            # 전체 포트폴리오 리스크 체크
            portfolio_risk = await self.risk_manager.check_portfolio_risk()
            
            if portfolio_risk['total_risk'] > self.config.trading.MAX_PORTFOLIO_RISK:
                self.logger.warning(f"⚠️ 포트폴리오 리스크 한도 초과: {portfolio_risk['total_risk']:.2%}")
                # 필요시 포지션 축소 로직
                
        except Exception as e:
            self.logger.error(f"❌ 리스크 체크 실패: {e}")
    
    # === 대화형 인터페이스 ===
    
    async def run_interactive_mode(self):
        """대화형 모드 실행"""
        self.print_banner()
        console.print(f"[dim]시작 시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}[/dim]\n")
        
        while True:
            try:
                self.show_main_menu()
                choice = self.get_user_choice()
                
                if choice == "0":
                    console.print("\n[bold]👋 프로그램을 종료합니다.[/bold]")
                    break
                
                # 메뉴 실행 (MenuHandlers에 위임)
                success = await self.menu_handlers.execute_menu_choice(choice)
                
                # 결과 표시
                if success:
                    console.print(Panel("[bold green]✅ 작업 완료[/bold green]", border_style="green"))
                elif success is False:  # None이 아닌 False인 경우에만
                    console.print(Panel("[bold red]❌ 작업 실패[/bold red]", border_style="red"))
                
                if choice != "0":
                    Prompt.ask("\n[dim]계속하려면 Enter를 누르세요[/dim]", default="")
                
            except KeyboardInterrupt:
                console.print("\n[yellow]🛑 사용자 중단[/yellow]")
                break
            except Exception as e:
                console.print(f"[red]❌ 오류 발생: {e}[/red]")
                self.logger.error(f"❌ 대화형 모드 오류: {e}")
                Prompt.ask("\n[dim]계속하려면 Enter를 누르세요[/dim]", default="")
    
    async def run_command_line_mode(self):
        """명령행 모드 실행"""
        parser = argparse.ArgumentParser(
            description="AI Trading System with Enhanced Analysis (5 Areas Integrated)",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
사용 예시:
  python main.py --mode test                     # 시스템 테스트
  python main.py --mode analysis                # 5개 영역 통합 분석
  python main.py --mode analysis --symbols 005930,000660  # 특정 종목 분석
  python main.py --mode supply-demand           # 수급 분석만 (NEW)
  python main.py --mode chart-pattern           # 차트패턴 분석만 (NEW)
  python main.py --mode backtest --strategy momentum --start 2024-01-01 --end 2024-12-31
  python main.py --mode trading --strategy momentum  # 자동매매 (위험!)
            """
        )
        
        parser.add_argument(
            '--mode', 
            choices=['test', 'analysis', 'news', 'supply-demand', 'chart-pattern', 'backtest', 'trading'],
            default='test',
            help='실행 모드'
        )
        
        parser.add_argument(
            '--strategy',
            choices=['momentum', 'breakout', 'eod'],
            default='momentum',
            help='분석/매매 전략'
        )
        
        parser.add_argument(
            '--symbols',
            type=str,
            help='분석할 종목 코드들 (쉼표로 구분, 예: 005930,000660)'
        )
        
        parser.add_argument(
            '--limit',
            type=int,
            default=100,
            help='분석할 최대 종목 수'
        )
        
        parser.add_argument(
            '--start',
            type=str,
            help='백테스트 시작 날짜 (YYYY-MM-DD)'
        )
        
        parser.add_argument(
            '--end',
            type=str,
            help='백테스트 종료 날짜 (YYYY-MM-DD)'
        )
        
        args = parser.parse_args()
        
        # 모드별 실행
        return await self._execute_command_mode(args)
    
    async def _execute_command_mode(self, args) -> bool:
        """명령 모드 실행"""
        try:
            console.print(f"[yellow]🚀 {args.mode} 모드 시작[/yellow]")
            
            if args.mode == 'test':
                return await self._run_system_test()
            
            elif args.mode == 'analysis':
                if args.symbols:
                    symbols = [s.strip() for s in args.symbols.split(',')]
                    results = await self.analyze_symbols(symbols, args.strategy)
                else:
                    results = await self.run_market_analysis(args.strategy, args.limit)
                
                # 결과 표시
                await self._display_analysis_results(results)
                return len(results) > 0
            
            elif args.mode == 'backtest':
                if not args.start or not args.end:
                    console.print("[red]❌ 백테스트에는 --start와 --end 파라미터가 필요합니다.[/red]")
                    return False
                
                symbols = None
                if args.symbols:
                    symbols = [s.strip() for s in args.symbols.split(',')]
                
                results = await self.run_backtest(args.strategy, args.start, args.end, symbols)
                await self._display_backtest_results(results)
                return True
            
            elif args.mode == 'trading':
                if not self.trading_enabled:
                    console.print("[red]❌ 매매 모드가 비활성화되어 있습니다.[/red]")
                    return False
                
                await self.run_auto_trading(args.strategy)
                return True
            
            else:
                console.print(f"[yellow]⚠️ {args.mode} 모드는 아직 구현되지 않았습니다.[/yellow]")
                return False
                
        except Exception as e:
            console.print(f"[red]❌ 명령 모드 실행 실패: {e}[/red]")
            self.logger.error(f"❌ 명령 모드 실행 실패: {e}")
            return False
    
    async def _run_system_test(self) -> bool:
        """시스템 테스트 실행"""
        console.print("[yellow]🔧 시스템 테스트 실행 중...[/yellow]")
        
        try:
            # 1. 컴포넌트 초기화 테스트
            console.print("[dim]1. 컴포넌트 초기화 테스트...[/dim]")
            if not await self.initialize_components():
                return False
            
            # 2. 데이터 수집 테스트
            console.print("[dim]2. 데이터 수집 테스트...[/dim]")
            test_symbol = "005930"  # 삼성전자
            stock_data = await self.data_collector.get_stock_data(test_symbol)
            if not stock_data:
                console.print("[red]❌ 데이터 수집 실패[/red]")
                return False
            
            # 3. 분석 엔진 테스트
            console.print("[dim]3. 분석 엔진 테스트...[/dim]")
            test_result = await self.analyze_symbol(test_symbol, "삼성전자", "momentum")
            if not test_result:
                console.print("[red]❌ 분석 엔진 테스트 실패[/red]")
                return False
            
            # 4. 데이터베이스 연결 테스트
            console.print("[dim]4. 데이터베이스 연결 테스트...[/dim]")
            if self.db_manager:
                db_status = await self.db_manager.check_connection()
                if not db_status:
                    console.print("[yellow]⚠️ 데이터베이스 연결 실패 (선택사항)[/yellow]")
            
            console.print("[green]✅ 모든 시스템 테스트 통과[/green]")
            return True
            
        except Exception as e:
            console.print(f"[red]❌ 시스템 테스트 실패: {e}[/red]")
            return False
    
    async def _display_analysis_results(self, results: List[AnalysisResult]):
        """분석 결과 표시"""
        if not results:
            console.print("[yellow]📊 분석 결과가 없습니다.[/yellow]")
            return
        
        # 상위 결과 테이블 생성
        table = Table(title=f"📊 분석 결과 (상위 {min(len(results), 20)}개)")
        table.add_column("순위", style="cyan", width=4)
        table.add_column("종목코드", style="magenta", width=8)
        table.add_column("종목명", style="white", width=15)
        table.add_column("점수", style="green", width=6)
        table.add_column("추천", style="yellow", width=10)
        table.add_column("리스크", style="red", width=8)
        table.add_column("전략", style="blue", width=10)
        
        for i, result in enumerate(results[:20]):
            table.add_row(
                str(i + 1),
                result.symbol,
                result.name[:12] + "..." if len(result.name) > 12 else result.name,
                f"{result.score:.1f}",
                result.recommendation,
                result.risk_level,
                result.strategy
            )
        
        console.print(table)
        
        # 요약 정보
        summary_panel = f"""
[bold]📈 분석 요약[/bold]

총 분석 종목: {len(results)}개
평균 점수: {sum(r.score for r in results) / len(results):.1f}점

추천 등급별:
• STRONG_BUY: {len([r for r in results if r.recommendation == 'STRONG_BUY'])}개
• BUY: {len([r for r in results if r.recommendation == 'BUY'])}개
• WEAK_BUY: {len([r for r in results if r.recommendation == 'WEAK_BUY'])}개
• HOLD: {len([r for r in results if r.recommendation == 'HOLD'])}개
• SELL: {len([r for r in results if r.recommendation == 'SELL'])}개

리스크 레벨별:
• LOW: {len([r for r in results if r.risk_level == 'LOW'])}개
• MEDIUM: {len([r for r in results if r.risk_level == 'MEDIUM'])}개
• HIGH: {len([r for r in results if r.risk_level == 'HIGH'])}개
        """
        
        console.print(Panel(summary_panel, title="📊 분석 요약", border_style="cyan"))
    
    async def _display_backtest_results(self, results: Dict[str, Any]):
        """백테스트 결과 표시"""
        if not results:
            console.print("[yellow]📈 백테스트 결과가 없습니다.[/yellow]")
            return
        
        # 백테스트 결과 요약
        summary = f"""
[bold]📈 백테스트 결과[/bold]

기간: {results.get('start_date', 'N/A')} ~ {results.get('end_date', 'N/A')}
전략: {results.get('strategy', 'N/A')}
초기 자본: {results.get('initial_capital', 0):,}원

[bold green]수익률 정보[/bold green]
총 수익률: {results.get('total_return', 0):.2%}
연환산 수익률: {results.get('annual_return', 0):.2%}
최대 낙폭(MDD): {results.get('max_drawdown', 0):.2%}
샤프 비율: {results.get('sharpe_ratio', 0):.2f}

[bold blue]거래 정보[/bold blue]
총 거래 횟수: {results.get('total_trades', 0)}회
승률: {results.get('win_rate', 0):.1%}
평균 수익: {results.get('avg_profit', 0):.2%}
평균 손실: {results.get('avg_loss', 0):.2%}
        """
        
        console.print(Panel(summary, title="📈 백테스트 결과", border_style="green"))
    
    # === 시스템 관리 ===
    
    async def get_system_status(self) -> Dict[str, Any]:
        """시스템 상태 조회"""
        status = {
            'timestamp': datetime.now().isoformat(),
            'trading_enabled': self.trading_enabled,
            'backtest_mode': self.backtest_mode,
            'is_running': self.is_running,
            'last_analysis_time': self.last_analysis_time.isoformat() if self.last_analysis_time else None,
            'components': {
                'data_collector': self.data_collector is not None,
                'news_collector': self.news_collector is not None,
                'analysis_engine': self.analysis_engine is not None,
                'strategies': len(self.strategies),
                'executor': self.executor is not None,
                'position_manager': self.position_manager is not None,
                'risk_manager': self.risk_manager is not None,
                'notifier': self.notifier is not None,
                'db_manager': self.db_manager is not None
            }
        }
        
        # 활성 포지션 수
        if self.position_manager:
            try:
                positions = await self.position_manager.get_active_positions()
                status['active_positions'] = len(positions)
            except:
                status['active_positions'] = 0
        else:
            status['active_positions'] = 0
        
        return status
    
    async def cleanup(self):
        """리소스 정리"""
        try:
            console.print("[yellow]🧹 리소스 정리 중...[/yellow]")
            
            # 자동매매 중단
            self.is_running = False
            
            # 데이터 수집기 정리
            if self.data_collector:
                await self.data_collector.close()
            
            # 매매 실행기 정리
            if self.executor:
                await self.executor.close()
            
            # 데이터베이스 연결 정리
            if self.db_manager:
                await self.db_manager.close()
            
            console.print("[green]✅ 리소스 정리 완료[/green]")
            self.logger.info("✅ 리소스 정리 완료")
            
        except Exception as e:
            console.print(f"[yellow]⚠️ 리소스 정리 중 오류: {e}[/yellow]")
            self.logger.warning(f"⚠️ 리소스 정리 중 오류: {e}")
    
    async def stop(self):
        """시스템 정지"""
        console.print("[yellow]🛑 시스템 정지 중...[/yellow]")
        self.logger.info("🛑 시스템 정지 중...")
        
        await self.cleanup()
        
        console.print("[bold]✅ 시스템 정지 완료[/bold]")
        self.logger.info("✅ 시스템 정지 완료")