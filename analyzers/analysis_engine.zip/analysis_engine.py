#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
trading_system/analyzers/analysis_engine.py

뉴스 분석이 통합된 종합 분석 엔진
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import asyncio

from utils.logger import get_logger

class AnalysisEngine:
    """뉴스 분석이 통합된 종합 분석 엔진"""
    
    def __init__(self, config):
        self.config = config
        self.logger = get_logger("AnalysisEngine")
        
        # 뉴스 수집기 초기화
        try:
            from data_collectors.news_collector import NewsCollector
            self.news_collector = NewsCollector(config)
            self.logger.info("✅ 뉴스 수집기 초기화 완료")
        except ImportError as e:
            self.logger.warning(f"⚠️ 뉴스 수집기 초기화 실패: {e}")
            self.news_collector = None
    
    def calculate_technical_score(self, stock_data) -> Dict:
        """기술적 분석 점수 계산"""
        try:
            # 더미 데이터로 기술적 분석 시뮬레이션
            # 실제로는 차트 데이터를 이용한 RSI, MACD, 볼린저밴드 등 계산
            
            # 기본 점수
            tech_score = 50.0
            
            # 가격 모멘텀 (등락률 기반)
            if hasattr(stock_data, 'change_rate'):
                if stock_data.change_rate > 5:
                    tech_score += 20
                elif stock_data.change_rate > 2:
                    tech_score += 10
                elif stock_data.change_rate < -5:
                    tech_score -= 20
                elif stock_data.change_rate < -2:
                    tech_score -= 10
            
            # 거래량 분석
            if hasattr(stock_data, 'volume'):
                if stock_data.volume > 1000000:  # 대량 거래
                    tech_score += 10
                elif stock_data.volume < 100000:  # 저조한 거래
                    tech_score -= 5
            
            # 52주 고저점 대비 위치
            if hasattr(stock_data, 'high_52w') and hasattr(stock_data, 'low_52w'):
                if stock_data.high_52w and stock_data.low_52w:
                    position_ratio = (stock_data.current_price - stock_data.low_52w) / (stock_data.high_52w - stock_data.low_52w)
                    if position_ratio > 0.8:  # 52주 고점 근처
                        tech_score += 15
                    elif position_ratio < 0.2:  # 52주 저점 근처
                        tech_score -= 15
            
            tech_score = max(0, min(100, tech_score))
            
            return {
                'overall_score': tech_score,
                'momentum_score': tech_score * 0.3,
                'volume_score': tech_score * 0.2,
                'position_score': tech_score * 0.2,
                'trend_score': tech_score * 0.3,
                'indicators': {
                    'rsi': np.random.uniform(30, 70),  # 더미 데이터
                    'macd_signal': 'neutral',
                    'bollinger_position': 'middle'
                }
            }
            
        except Exception as e:
            self.logger.warning(f"⚠️ 기술적 분석 실패: {e}")
            return {
                'overall_score': 50.0,
                'momentum_score': 50.0,
                'volume_score': 50.0,
                'position_score': 50.0,
                'trend_score': 50.0,
                'indicators': {}
            }
    
    def calculate_fundamental_score(self, stock_data) -> Dict:
        """펀더멘털 분석 점수 계산"""
        try:
            fund_score = 50.0
            
            # PER 분석
            if hasattr(stock_data, 'pe_ratio') and stock_data.pe_ratio:
                if 5 <= stock_data.pe_ratio <= 15:
                    fund_score += 15
                elif 15 < stock_data.pe_ratio <= 25:
                    fund_score += 5
                elif stock_data.pe_ratio > 30:
                    fund_score -= 10
            
            # PBR 분석
            if hasattr(stock_data, 'pbr') and stock_data.pbr:
                if 0.5 <= stock_data.pbr <= 1.5:
                    fund_score += 10
                elif stock_data.pbr > 3:
                    fund_score -= 10
            
            # 시가총액 안정성
            if hasattr(stock_data, 'market_cap') and stock_data.market_cap:
                if stock_data.market_cap > 10000:  # 대형주
                    fund_score += 10
                elif stock_data.market_cap > 5000:  # 중형주
                    fund_score += 5
            
            fund_score = max(0, min(100, fund_score))
            
            return {
                'overall_score': fund_score,
                'valuation_score': fund_score * 0.4,
                'profitability_score': fund_score * 0.3,
                'stability_score': fund_score * 0.3,
                'metrics': {
                    'per': getattr(stock_data, 'pe_ratio', None),
                    'pbr': getattr(stock_data, 'pbr', None),
                    'market_cap': getattr(stock_data, 'market_cap', None)
                }
            }
            
        except Exception as e:
            self.logger.warning(f"⚠️ 펀더멘털 분석 실패: {e}")
            return {
                'overall_score': 50.0,
                'valuation_score': 50.0,
                'profitability_score': 50.0,
                'stability_score': 50.0,
                'metrics': {}
            }
    
    def calculate_news_sentiment_score(self, symbol: str, name: str) -> Dict:
        """뉴스 감정 분석 점수 계산"""
        try:
            if not self.news_collector:
                return {
                    'overall_score': 50.0,
                    'material_score': 0.0,
                    'sentiment_score': 0.0,
                    'news_count': 0,
                    'material_type': '재료없음',
                    'keywords': [],
                    'has_material': False
                }
            
            # 뉴스 분석 실행
            news_analysis = self.news_collector.get_news_analysis_summary(name, symbol)
            
            # 기본 감정 점수 (50점 기준)
            base_score = 50.0
            
            # 뉴스 재료 점수 적용
            material_score = news_analysis.get('material_score', 0)
            
            # 뉴스 재료 타입별 가중치
            material_weights = {
                '장기재료': 1.5,
                '중기재료': 1.2,
                '단기재료': 1.0,
                '재료없음': 0.0
            }
            
            material_type = news_analysis.get('material_type', '재료없음')
            material_weight = material_weights.get(material_type, 0.0)
            
            # 재료 점수를 0-40점 범위로 정규화 (최대 40점 보너스)
            normalized_material_score = min(40, material_score * material_weight * 2)
            
            # 감정 점수 적용 (-10 ~ +10점)
            sentiment_score = news_analysis.get('sentiment_score', 0)
            sentiment_bonus = sentiment_score * 10
            
            # 뉴스 개수 보너스 (최대 5점)
            news_count = news_analysis.get('news_count', 0)
            news_bonus = min(5, news_count)
            
            # 최종 점수 계산
            final_score = base_score + normalized_material_score + sentiment_bonus + news_bonus
            final_score = max(0, min(100, final_score))
            
            self.logger.info(f"   📰 뉴스 분석: {material_type} (재료점수: {material_score:.1f}, 최종점수: {final_score:.1f})")
            
            return {
                'overall_score': final_score,
                'material_score': normalized_material_score,
                'sentiment_score': sentiment_bonus,
                'news_count': news_count,
                'material_type': material_type,
                'keywords': news_analysis.get('keywords', []),
                'has_material': news_analysis.get('has_material', False),
                'raw_material_score': material_score
            }
            
        except Exception as e:
            self.logger.warning(f"⚠️ 뉴스 감정 분석 실패: {e}")
            return {
                'overall_score': 50.0,
                'material_score': 0.0,
                'sentiment_score': 0.0,
                'news_count': 0,
                'material_type': '재료없음',
                'keywords': [],
                'has_material': False
            }
    
    async def analyze_comprehensive(self, symbol: str, name: str, stock_data, 
                                  news_data: Dict = None, strategy: str = "momentum") -> Dict:
        """종합 분석 실행 (뉴스 분석 포함)"""
        try:
            self.logger.info(f"🔬 {symbol} ({name}) 종합 분석 시작...")
            
            # 각 분석 영역별 점수 계산
            technical_analysis = self.calculate_technical_score(stock_data)
            fundamental_analysis = self.calculate_fundamental_score(stock_data)
            
            # 뉴스 감정 분석 (새로 추가)
            news_sentiment_analysis = self.calculate_news_sentiment_score(symbol, name)
            
            # 가중치 설정 (뉴스 분석 추가로 조정)
            weights = {
                'technical': 0.35,      # 기술적 분석 35%
                'fundamental': 0.35,    # 펀더멘털 분석 35%
                'news_sentiment': 0.30  # 뉴스 감정 분석 30%
            }
            
            # 종합 점수 계산
            comprehensive_score = (
                technical_analysis['overall_score'] * weights['technical'] +
                fundamental_analysis['overall_score'] * weights['fundamental'] +
                news_sentiment_analysis['overall_score'] * weights['news_sentiment']
            )
            
            # 뉴스 재료가 있는 경우 추가 보너스
            if news_sentiment_analysis.get('has_material', False):
                material_bonus = 0
                material_type = news_sentiment_analysis.get('material_type')
                
                if material_type == '장기재료':
                    material_bonus = 8
                elif material_type == '중기재료':
                    material_bonus = 5
                elif material_type == '단기재료':
                    material_bonus = 3
                
                comprehensive_score += material_bonus
                self.logger.info(f"   🎁 재료 보너스: +{material_bonus}점 ({material_type})")
            
            comprehensive_score = max(0, min(100, comprehensive_score))
            
            # 신호 강도 및 타입 결정
            signal_strength = self._calculate_signal_strength(
                technical_analysis, fundamental_analysis, news_sentiment_analysis
            )
            signal_type = self._determine_signal_type(comprehensive_score, news_sentiment_analysis)
            
            # 추천 등급 결정
            recommendation = self._determine_recommendation(
                comprehensive_score, signal_strength, news_sentiment_analysis
            )
            
            # 신뢰도 계산
            confidence = self._calculate_confidence(
                technical_analysis, fundamental_analysis, news_sentiment_analysis
            )
            
            # 리스크 레벨 결정
            risk_level = self._determine_risk_level(stock_data, news_sentiment_analysis)
            
            # 매매 액션 결정
            action = self._determine_action(recommendation, signal_strength, risk_level)
            
            result = {
                'symbol': symbol,
                'name': name,
                'comprehensive_score': comprehensive_score,
                'technical_analysis': technical_analysis,
                'fundamental_analysis': fundamental_analysis,
                'sentiment_analysis': news_sentiment_analysis,  # 뉴스 분석 결과
                'signal_strength': signal_strength,
                'signal_type': signal_type,
                'recommendation': recommendation,
                'confidence': confidence,
                'risk_level': risk_level,
                'action': action,
                'strategy': strategy,
                'analysis_time': datetime.now().isoformat(),
                'weights_used': weights
            }
            
            self.logger.info(f"✅ {symbol} 종합 분석 완료 - 점수: {comprehensive_score:.1f}, 추천: {recommendation}")
            
            return result
            
        except Exception as e:
            self.logger.error(f"❌ {symbol} 종합 분석 실패: {e}")
            return None
    
    def _calculate_signal_strength(self, technical: Dict, fundamental: Dict, news: Dict) -> float:
        """신호 강도 계산"""
        try:
            # 각 분석의 편차를 기준으로 신호 강도 계산
            tech_deviation = abs(technical['overall_score'] - 50) / 50
            fund_deviation = abs(fundamental['overall_score'] - 50) / 50
            news_deviation = abs(news['overall_score'] - 50) / 50
            
            # 뉴스 재료가 있으면 신호 강도 증가
            if news.get('has_material', False):
                news_deviation *= 1.5
            
            signal_strength = (tech_deviation + fund_deviation + news_deviation) / 3 * 100
            return min(100, signal_strength)
            
        except Exception:
            return 50.0
    
    def _determine_signal_type(self, score: float, news: Dict) -> str:
        """신호 타입 결정"""
        try:
            material_type = news.get('material_type', '재료없음')
            
            if score >= 70:
                if material_type in ['장기재료', '중기재료']:
                    return 'STRONG_BUY_SIGNAL'
                else:
                    return 'BUY_SIGNAL'
            elif score >= 60:
                return 'WEAK_BUY_SIGNAL'
            elif score <= 30:
                return 'SELL_SIGNAL'
            elif score <= 40:
                return 'WEAK_SELL_SIGNAL'
            else:
                return 'NEUTRAL_SIGNAL'
                
        except Exception:
            return 'NEUTRAL_SIGNAL'
    
    def _determine_recommendation(self, score: float, signal_strength: float, news: Dict) -> str:
        """추천 등급 결정"""
        try:
            has_material = news.get('has_material', False)
            
            if score >= 75 and signal_strength >= 60:
                return 'STRONG_BUY'
            elif score >= 65 and (signal_strength >= 50 or has_material):
                return 'BUY'
            elif score >= 55:
                return 'WEAK_BUY'
            elif score <= 25:
                return 'STRONG_SELL'
            elif score <= 35:
                return 'SELL'
            elif score <= 45:
                return 'WEAK_SELL'
            else:
                return 'HOLD'
                
        except Exception:
            return 'HOLD'
    
    def _calculate_confidence(self, technical: Dict, fundamental: Dict, news: Dict) -> float:
        """신뢰도 계산"""
        try:
            # 각 분석 결과의 일관성을 기준으로 신뢰도 계산
            scores = [
                technical['overall_score'],
                fundamental['overall_score'],
                news['overall_score']
            ]
            
            # 표준편차가 낮을수록 신뢰도 높음
            std_dev = np.std(scores)
            confidence = max(0.3, 1.0 - (std_dev / 50))
            
            # 뉴스 재료가 있으면 신뢰도 증가
            if news.get('has_material', False):
                confidence = min(1.0, confidence + 0.1)
            
            return confidence
            
        except Exception:
            return 0.5
    
    def _determine_risk_level(self, stock_data, news: Dict) -> str:
        """리스크 레벨 결정"""
        try:
            risk_score = 50  # 기본 리스크
            
            # 변동성 기반 리스크
            if hasattr(stock_data, 'change_rate'):
                if abs(stock_data.change_rate) > 10:
                    risk_score += 20
                elif abs(stock_data.change_rate) > 5:
                    risk_score += 10
            
            # 시가총액 기반 리스크
            if hasattr(stock_data, 'market_cap') and stock_data.market_cap:
                if stock_data.market_cap < 1000:  # 소형주
                    risk_score += 15
                elif stock_data.market_cap > 10000:  # 대형주
                    risk_score -= 10
            
            # 뉴스 재료 기반 리스크 조정
            material_type = news.get('material_type', '재료없음')
            if material_type == '단기재료':
                risk_score += 10  # 단기 재료는 리스크 증가
            elif material_type == '장기재료':
                risk_score -= 5   # 장기 재료는 리스크 감소
            
            if risk_score >= 70:
                return 'HIGH'
            elif risk_score >= 55:
                return 'MEDIUM_HIGH'
            elif risk_score <= 35:
                return 'LOW'
            elif risk_score <= 45:
                return 'MEDIUM_LOW'
            else:
                return 'MEDIUM'
                
        except Exception:
            return 'MEDIUM'
    
    def _determine_action(self, recommendation: str, signal_strength: float, risk_level: str) -> str:
        """매매 액션 결정"""
        try:
            if recommendation in ['STRONG_BUY', 'BUY'] and signal_strength >= 60 and risk_level not in ['HIGH']:
                return 'BUY'
            elif recommendation in ['STRONG_SELL', 'SELL'] and signal_strength >= 60:
                return 'SELL'
            elif recommendation == 'WEAK_BUY' and risk_level in ['LOW', 'MEDIUM_LOW']:
                return 'WEAK_BUY'
            elif recommendation == 'WEAK_SELL':
                return 'WEAK_SELL'
            else:
                return 'HOLD'
                
        except Exception:
            return 'HOLD'
    
    async def get_analysis_summary(self, results: List[Dict]) -> Dict:
        """분석 결과 요약"""
        try:
            if not results:
                return {}
            
            # 기본 통계
            total_analyzed = len(results)
            avg_score = sum(r['comprehensive_score'] for r in results) / total_analyzed
            
            # 추천 분포
            recommendations = {}
            for result in results:
                rec = result['recommendation']
                recommendations[rec] = recommendations.get(rec, 0) + 1
            
            # 매수 신호 개수
            buy_signals = len([r for r in results if r['recommendation'] in ['BUY', 'STRONG_BUY']])
            
            # 고득점 종목 (80점 이상)
            high_score_count = len([r for r in results if r['comprehensive_score'] >= 80])
            
            # 뉴스 재료 보유 종목
            material_stocks = len([r for r in results if r['sentiment_analysis'].get('has_material', False)])
            
            return {
                'total_analyzed': total_analyzed,
                'average_score': avg_score,
                'recommendations': recommendations,
                'buy_signals': buy_signals,
                'high_score_count': high_score_count,
                'material_stocks': material_stocks,
                'analysis_time': datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"❌ 분석 요약 실패: {e}")
            return {}
    # analysis_engine.py에 추가할 메서드들

async def analyze_stock(self, stock_data, strategy: str = "momentum", include_news: bool = True) -> Dict:
    """단일 종목 분석 - analyze_comprehensive의 래퍼 함수"""
    try:
        # StockData 객체에서 symbol과 name 추출
        if hasattr(stock_data, 'symbol') and hasattr(stock_data, 'name'):
            symbol = stock_data.symbol
            name = stock_data.name
        else:
            # Dict 형태인 경우
            symbol = stock_data.get('symbol', 'UNKNOWN')
            name = stock_data.get('name', 'Unknown')
        
        # include_news가 False면 뉴스 분석 제외
        if not include_news:
            return await self.analyze_without_news(symbol, name, stock_data, strategy)
        
        # 기존 종합 분석 호출
        return await self.analyze_comprehensive(symbol, name, stock_data, strategy=strategy)
        
    except Exception as e:
        self.logger.error(f"❌ {getattr(stock_data, 'symbol', 'UNKNOWN')} 종목 분석 실패: {e}")
        return None

async def analyze_without_news(self, symbol: str, name: str, stock_data, strategy: str = "momentum") -> Dict:
    """뉴스 분석 제외한 종목 분석"""
    try:
        self.logger.info(f"🔬 {symbol} ({name}) 분석 시작 (뉴스 제외)...")
        
        # 기술적 분석과 펀더멘털 분석만 수행
        technical_analysis = self.calculate_technical_score(stock_data)
        fundamental_analysis = self.calculate_fundamental_score(stock_data)
        
        # 뉴스 분석은 기본값으로 설정
        news_sentiment_analysis = {
            'overall_score': 50.0,
            'material_score': 0.0,
            'sentiment_score': 0.0,
            'news_count': 0,
            'material_type': '재료없음',
            'keywords': [],
            'has_material': False
        }
        
        # 가중치 설정 (뉴스 제외)
        weights = {
            'technical': 0.50,      # 기술적 분석 50%
            'fundamental': 0.50,    # 펀더멘털 분석 50%
            'news_sentiment': 0.00  # 뉴스 분석 0%
        }
        
        # 종합 점수 계산
        comprehensive_score = (
            technical_analysis['overall_score'] * weights['technical'] +
            fundamental_analysis['overall_score'] * weights['fundamental']
        )
        
        comprehensive_score = max(0, min(100, comprehensive_score))
        
        # 신호 강도 및 타입 결정
        signal_strength = self._calculate_signal_strength(
            technical_analysis, fundamental_analysis, news_sentiment_analysis
        )
        signal_type = self._determine_signal_type(comprehensive_score, news_sentiment_analysis)
        
        # 추천 등급 결정
        recommendation = self._determine_recommendation(
            comprehensive_score, signal_strength, news_sentiment_analysis
        )
        
        # 신뢰도 계산
        confidence = self._calculate_confidence(
            technical_analysis, fundamental_analysis, news_sentiment_analysis
        )
        
        # 리스크 레벨 결정
        risk_level = self._determine_risk_level(stock_data, news_sentiment_analysis)
        
        # 매매 액션 결정
        action = self._determine_action(recommendation, signal_strength, risk_level)
        
        result = {
            'symbol': symbol,
            'name': name,
            'comprehensive_score': comprehensive_score,
            'technical_analysis': technical_analysis,
            'fundamental_analysis': fundamental_analysis,
            'sentiment_analysis': news_sentiment_analysis,
            'signal_strength': signal_strength,
            'signal_type': signal_type,
            'recommendation': recommendation,
            'confidence': confidence,
            'risk_level': risk_level,
            'action': action,
            'strategy': strategy,
            'analysis_time': datetime.now().isoformat(),
            'weights_used': weights
        }
        
        self.logger.info(f"✅ {symbol} 분석 완료 - 점수: {comprehensive_score:.1f}, 추천: {recommendation}")
        
        return result
        
    except Exception as e:
        self.logger.error(f"❌ {symbol} 분석 실패: {e}")
        return None

# 기존 analyze_comprehensive 메서드도 약간 수정
async def analyze_comprehensive(self, symbol: str, name: str, stock_data, 
                              news_data: Dict = None, strategy: str = "momentum") -> Dict:
    """종합 분석 실행 (뉴스 분석 포함) - 개선된 버전"""
    try:
        self.logger.info(f"🔬 {symbol} ({name}) 종합 분석 시작...")
        
        # 각 분석 영역별 점수 계산
        technical_analysis = self.calculate_technical_score(stock_data)
        fundamental_analysis = self.calculate_fundamental_score(stock_data)
        
        # 뉴스 감정 분석
        news_sentiment_analysis = self.calculate_news_sentiment_score(symbol, name)
        
        # 가중치 설정 (뉴스 분석 추가로 조정)
        weights = {
            'technical': 0.35,      # 기술적 분석 35%
            'fundamental': 0.35,    # 펀더멘털 분석 35%
            'news_sentiment': 0.30  # 뉴스 감정 분석 30%
        }
        
        # 종합 점수 계산
        comprehensive_score = (
            technical_analysis['overall_score'] * weights['technical'] +
            fundamental_analysis['overall_score'] * weights['fundamental'] +
            news_sentiment_analysis['overall_score'] * weights['news_sentiment']
        )
        
        # 뉴스 재료가 있는 경우 추가 보너스
        if news_sentiment_analysis.get('has_material', False):
            material_bonus = 0
            material_type = news_sentiment_analysis.get('material_type')
            
            if material_type == '장기재료':
                material_bonus = 8
            elif material_type == '중기재료':
                material_bonus = 5
            elif material_type == '단기재료':
                material_bonus = 3
            
            comprehensive_score += material_bonus
            self.logger.info(f"   🎁 재료 보너스: +{material_bonus}점 ({material_type})")
        
        comprehensive_score = max(0, min(100, comprehensive_score))
        
        # 신호 강도 및 타입 결정
        signal_strength = self._calculate_signal_strength(
            technical_analysis, fundamental_analysis, news_sentiment_analysis
        )
        signal_type = self._determine_signal_type(comprehensive_score, news_sentiment_analysis)
        
        # 추천 등급 결정
        recommendation = self._determine_recommendation(
            comprehensive_score, signal_strength, news_sentiment_analysis
        )
        
        # 신뢰도 계산
        confidence = self._calculate_confidence(
            technical_analysis, fundamental_analysis, news_sentiment_analysis
        )
        
        # 리스크 레벨 결정
        risk_level = self._determine_risk_level(stock_data, news_sentiment_analysis)
        
        # 매매 액션 결정
        action = self._determine_action(recommendation, signal_strength, risk_level)
        
        result = {
            'symbol': symbol,
            'name': name,
            'comprehensive_score': comprehensive_score,
            'technical_analysis': technical_analysis,
            'fundamental_analysis': fundamental_analysis,
            'sentiment_analysis': news_sentiment_analysis,  # 뉴스 분석 결과
            'signal_strength': signal_strength,
            'signal_type': signal_type,
            'recommendation': recommendation,
            'confidence': confidence,
            'risk_level': risk_level,
            'action': action,
            'strategy': strategy,
            'analysis_time': datetime.now().isoformat(),
            'weights_used': weights
        }
        
        self.logger.info(f"✅ {symbol} 종합 분석 완료 - 점수: {comprehensive_score:.1f}, 추천: {recommendation}")
        
        return result
        
    except Exception as e:
        self.logger.error(f"❌ {symbol} 종합 분석 실패: {e}")
        return None

# 안전한 종목 분석을 위한 헬퍼 함수
async def safe_analyze_stock(self, stock_data, strategy: str = "momentum", include_news: bool = True) -> Optional[Dict]:
    """안전한 종목 분석 - 오류 처리 강화"""
    try:
        # 입력 데이터 검증
        if stock_data is None:
            self.logger.warning("⚠️ stock_data가 None입니다.")
            return None
        
        # StockData 객체 또는 딕셔너리에서 기본 정보 추출
        symbol = getattr(stock_data, 'symbol', None) or stock_data.get('symbol', 'UNKNOWN')
        name = getattr(stock_data, 'name', None) or stock_data.get('name', 'Unknown')
        
        if symbol == 'UNKNOWN':
            self.logger.warning(f"⚠️ 유효하지 않은 종목 데이터: {stock_data}")
            return None
        
        # 분석 실행
        result = await self.analyze_stock(stock_data, strategy, include_news)
        
        if result:
            self.logger.debug(f"✅ {symbol} 분석 성공")
        else:
            self.logger.warning(f"⚠️ {symbol} 분석 결과 없음")
        
        return result
        
    except Exception as e:
        symbol = getattr(stock_data, 'symbol', 'UNKNOWN')
        self.logger.error(f"❌ {symbol} 안전한 분석 실패: {e}")
        return None