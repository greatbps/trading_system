#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
trading_system/data_collectors/kis_collector.py

한국투자증권 KIS API 데이터 수집기
"""

import asyncio
import aiohttp
import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from pathlib import Path

from utils.logger import get_logger

@dataclass
class StockData:
    """주식 데이터 클래스"""
    symbol: str
    name: str
    current_price: float
    change_rate: float
    volume: int
    trading_value: float
    market_cap: float
    shares_outstanding: int
    high_52w: float
    low_52w: float
    pe_ratio: Optional[float] = None
    pbr: Optional[float] = None
    eps: Optional[float] = None
    bps: Optional[float] = None
    sector: Optional[str] = None

class KISCollector:
    """한국투자증권 KIS API 데이터 수집기"""
    
    def __init__(self, config):
        self.config = config
        self.logger = get_logger("KISCollector")
        self.base_url = config.api.KIS_BASE_URL
        self.app_key = config.api.KIS_APP_KEY
        self.app_secret = config.api.KIS_APP_SECRET
        self.is_virtual = config.api.KIS_VIRTUAL_ACCOUNT
        
        # 세션 관리
        self.session: Optional[aiohttp.ClientSession] = None
        self.access_token: Optional[str] = None
        self.token_expired: Optional[datetime] = None
        
        # 토큰 저장 파일 경로
        self.token_file = Path("data/kis_token.json")
        self.token_file.parent.mkdir(exist_ok=True)
        
        # API 키 검증
        if not self.app_key or not self.app_secret:
            raise ValueError("KIS API 키가 설정되지 않았습니다. .env 파일을 확인하세요.")
    
    async def __aenter__(self):
        """비동기 컨텍스트 매니저 진입"""
        await self.initialize()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """비동기 컨텍스트 매니저 종료 - 개선"""
        try:
            await self.close()
        except Exception as e:
            self.logger.warning(f"⚠️ 컨텍스트 매니저 종료 중 오류 (무시됨): {e}")
        finally:
            # 강제 정리
            self.session = None
    
    async def initialize(self):
        """KIS API 초기화"""
        self.logger.info("🔌 KIS API 연결 초기화 중...")
        
        # HTTP 세션 생성
        connector = aiohttp.TCPConnector(
            limit=10,
            limit_per_host=5,
            ttl_dns_cache=300,
            use_dns_cache=True,
            enable_cleanup_closed=True
        )
        
        timeout = aiohttp.ClientTimeout(total=30, connect=10)
        self.session = aiohttp.ClientSession(
            connector=connector,
            timeout=timeout,
            headers={
                'Content-Type': 'application/json',
                'User-Agent': 'Trading-System/1.0'
            }
        )
        
        # 저장된 토큰 확인 후 토큰 발급/갱신
        if await self._load_saved_token():
            self.logger.info("✅ 저장된 토큰 사용")
            self._update_session_headers()
        else:
            # 새 토큰 발급
            success = await self._get_access_token()
            if not success:
                raise ConnectionError("KIS API 토큰 발급에 실패했습니다. API 키를 확인하세요.")
        
        self.logger.info("✅ KIS API 초기화 완료")
        return True
    
    def _load_token_from_file(self) -> Optional[Dict]:
        """파일에서 토큰 정보 로드"""
        try:
            if not self.token_file.exists():
                return None
            
            with open(self.token_file, 'r', encoding='utf-8') as f:
                token_data = json.load(f)
            
            # 토큰 데이터 검증
            required_fields = ['access_token', 'expired_at', 'app_key', 'app_secret']
            if not all(field in token_data for field in required_fields):
                self.logger.warning("⚠️ 저장된 토큰 데이터가 불완전함")
                return None
            
            # API 키가 현재와 일치하는지 확인
            if (token_data['app_key'] != self.app_key or 
                token_data['app_secret'] != self.app_secret):
                self.logger.warning("⚠️ API 키가 변경되어 저장된 토큰 무효")
                return None
            
            return token_data
            
        except Exception as e:
            self.logger.warning(f"⚠️ 토큰 파일 로드 실패: {e}")
            return None
    
    def _save_token_to_file(self):
        """토큰 정보를 파일에 저장"""
        try:
            if not self.access_token or not self.token_expired:
                return False
            
            token_data = {
                'access_token': self.access_token,
                'expired_at': self.token_expired.isoformat(),
                'app_key': self.app_key,
                'app_secret': self.app_secret,
                'created_at': datetime.now().isoformat()
            }
            
            with open(self.token_file, 'w', encoding='utf-8') as f:
                json.dump(token_data, f, indent=2, ensure_ascii=False)
            
            self.logger.info("💾 토큰 정보 저장 완료")
            return True
            
        except Exception as e:
            self.logger.warning(f"⚠️ 토큰 저장 실패: {e}")
            return False
    
    async def _load_saved_token(self) -> bool:
        """저장된 토큰 로드 및 유효성 검사"""
        try:
            token_data = self._load_token_from_file()
            if not token_data:
                return False
            
            # 만료 시간 파싱
            expired_at = datetime.fromisoformat(token_data['expired_at'])
            
            # 토큰이 유효한지 확인 (1시간 여유 두기)
            now = datetime.now()
            if now >= expired_at - timedelta(hours=1):
                self.logger.info("🔄 저장된 토큰이 곧 만료됨. 새 토큰 발급 필요")
                return False
            
            # 토큰 정보 설정
            self.access_token = token_data['access_token']
            self.token_expired = expired_at
            
            created_at = datetime.fromisoformat(token_data['created_at'])
            remaining_hours = (expired_at - now).total_seconds() / 3600
            
            self.logger.info(f"✅ 저장된 토큰 로드 성공 (생성: {created_at.strftime('%Y-%m-%d %H:%M')}, 남은시간: {remaining_hours:.1f}시간)")
            return True
            
        except Exception as e:
            self.logger.warning(f"⚠️ 저장된 토큰 로드 실패: {e}")
            return False
    
    def _update_session_headers(self):
        """세션 헤더에 토큰 업데이트"""
        if self.session and self.access_token:
            self.session.headers.update({
                'Authorization': f'Bearer {self.access_token}',
                'appkey': self.app_key,
                'appsecret': self.app_secret
            })
    
    async def close(self):
        """리소스 정리 - 개선된 버전"""
        try:
            if self.session and not self.session.closed:
                try:
                    # 모든 pending 작업 완료 대기
                    if hasattr(self.session, '_connector') and self.session._connector:
                        # 커넥터의 모든 연결 종료
                        await self.session._connector.close()
                    
                    # 세션 종료
                    await self.session.close()
                    
                    # 충분한 대기 시간으로 정리 완료 보장
                    await asyncio.sleep(0.25)
                    
                except Exception as e:
                    self.logger.debug(f"세션 종료 중 오류 (무시됨): {e}")
                
            self.session = None
            self.logger.info("✅ KIS API 연결 종료")
            
        except Exception as e:
            self.logger.warning(f"⚠️ KIS API 연결 종료 중 오류: {e}")
        finally:
            # 강제로 세션을 None으로 설정
            self.session = None
    
    async def _get_access_token(self) -> bool:
        """액세스 토큰 발급"""
        try:
            self.logger.info("🔑 새 액세스 토큰 발급 시도...")
            
            url = f"{self.base_url}/oauth2/tokenP"
            
            data = {
                "grant_type": "client_credentials",
                "appkey": self.app_key,
                "appsecret": self.app_secret
            }
            
            async with self.session.post(url, json=data) as response:
                response_text = await response.text()
                
                if response.status == 200:
                    result = json.loads(response_text)
                    self.access_token = result.get('access_token')
                    
                    # 토큰 만료 시간 설정 (24시간)
                    self.token_expired = datetime.now() + timedelta(hours=23, minutes=50)
                    
                    # 세션 헤더에 토큰 추가
                    self._update_session_headers()
                    
                    # 토큰을 파일에 저장
                    self._save_token_to_file()
                    
                    self.logger.info("✅ 새 액세스 토큰 발급 성공")
                    return True
                else:
                    self.logger.error(f"❌ 액세스 토큰 발급 실패: {response.status}, {response_text}")
                    return False
                    
        except Exception as e:
            self.logger.error(f"❌ 액세스 토큰 발급 실패: {e}")
            return False
    
    async def _check_token_validity(self) -> bool:
        """토큰 유효성 검사"""
        if not self.access_token or not self.token_expired:
            return False
        
        # 토큰이 만료되기 1시간 전에 갱신
        if datetime.now() >= self.token_expired - timedelta(hours=1):
            self.logger.info("🔄 액세스 토큰 갱신 중...")
            return await self._get_access_token()
        
        return True
    
    async def get_stock_list(self) -> List[Tuple[str, str]]:
        """전체 상장 종목 리스트 조회 - 여러 방법 시도"""
        try:
            self.logger.info("📋 상장 종목 리스트 조회 중...")
            
            # 방법 1: pykrx 라이브러리 사용 (가장 안정적)
            try:
                self.logger.info("🔍 방법 1: pykrx 라이브러리 시도...")
                stocks = await self._get_stock_list_pykrx()
                self.logger.info(f"✅ pykrx로 {len(stocks)}개 종목 조회 성공!")
                return stocks
            except ImportError as e:
                self.logger.warning(f"⚠️ pykrx 라이브러리가 설치되지 않았습니다: {e}")
                self.logger.info("💡 설치 명령: pip install pykrx")
            except Exception as e:
                self.logger.warning(f"⚠️ pykrx 사용 실패: {e}")
            
            # 방법 2: KRX 웹사이트 직접 크롤링
            try:
                self.logger.info("🔍 방법 2: KRX 웹사이트 직접 접근 시도...")
                stocks = await self._get_stock_list_krx_web()
                self.logger.info(f"✅ KRX 웹사이트로 {len(stocks)}개 종목 조회 성공!")
                return stocks
            except Exception as e:
                self.logger.warning(f"⚠️ KRX 웹사이트 접근 실패: {e}")
            
            # 방법 3: 간단한 테스트 데이터 (개발/테스트용)
            try:
                self.logger.info("🔍 방법 3: 테스트 데이터 사용...")
                test_stocks = [
                    ("005930", "삼성전자"),
                    ("000660", "SK하이닉스"),
                    ("035720", "카카오"),
                    ("005490", "POSCO홀딩스"),
                    ("051910", "LG화학"),
                    ("006400", "삼성SDI"),
                    ("035420", "NAVER"),
                    ("105560", "KB금융"),
                    ("055550", "신한지주"),
                    ("068270", "셀트리온"),
                    ("207940", "삼성바이오로직스"),
                    ("373220", "LG에너지솔루션"),
                    ("086520", "에코프로"),
                    ("247540", "에코프로비엠"),
                    ("066570", "LG전자"),
                    ("000270", "기아"),
                    ("005380", "현대차"),
                    ("012330", "현대모비스"),
                    ("003550", "LG"),
                    ("096770", "SK이노베이션")
                ]
                self.logger.info(f"✅ 테스트 데이터로 {len(test_stocks)}개 종목 사용")
                self.logger.warning("⚠️ 주의: 실제 전체 종목이 아닌 테스트용 주요 종목만 사용 중입니다.")
                return test_stocks
            except Exception as e:
                self.logger.error(f"❌ 테스트 데이터 사용 실패: {e}")
            
            raise Exception("모든 종목 리스트 조회 방법이 실패했습니다.")
            
        except Exception as e:
            self.logger.error(f"❌ 종목 리스트 조회 실패: {e}")
            raise e
    
    async def _get_stock_list_pykrx(self) -> List[Tuple[str, str]]:
        """pykrx 라이브러리를 사용한 종목 리스트 조회"""
        try:
            from pykrx import stock
            import pandas as pd
            from datetime import datetime
            
            self.logger.info("✅ pykrx 라이브러리 로드 성공")
            
            # 오늘 날짜 (YYYYMMDD 형식)
            today = datetime.now().strftime("%Y%m%d")
            self.logger.info(f"📅 조회 기준일: {today}")
            
            all_stocks = []
            
            # KOSPI 종목 조회
            try:
                self.logger.info("📊 pykrx - KOSPI 종목 조회 중...")
                kospi_tickers = stock.get_market_ticker_list(today, market="KOSPI")
                
                kospi_stocks = []
                for ticker in kospi_tickers:
                    try:
                        name = stock.get_market_ticker_name(ticker)
                        if name and len(ticker) == 6:
                            kospi_stocks.append((ticker, name))
                    except Exception:
                        continue
                
                all_stocks.extend(kospi_stocks)
                self.logger.info(f"✅ pykrx - KOSPI 종목 {len(kospi_stocks)}개 조회 완료")
                
                # 처음 5개 종목 로그 출력 (확인용)
                for i, (code, name) in enumerate(kospi_stocks[:5]):
                    self.logger.info(f"   📋 KOSPI 예시 {i+1}: {code} - {name}")
                    
            except Exception as e:
                self.logger.warning(f"⚠️ pykrx - KOSPI 조회 실패: {e}")
            
            # KOSDAQ 종목 조회
            try:
                self.logger.info("📊 pykrx - KOSDAQ 종목 조회 중...")
                kosdaq_tickers = stock.get_market_ticker_list(today, market="KOSDAQ")
                
                kosdaq_stocks = []
                for ticker in kosdaq_tickers:
                    try:
                        name = stock.get_market_ticker_name(ticker)
                        if name and len(ticker) == 6:
                            kosdaq_stocks.append((ticker, name))
                    except Exception:
                        continue
                
                all_stocks.extend(kosdaq_stocks)
                self.logger.info(f"✅ pykrx - KOSDAQ 종목 {len(kosdaq_stocks)}개 조회 완료")
                
                # 처음 5개 종목 로그 출력 (확인용)
                for i, (code, name) in enumerate(kosdaq_stocks[:5]):
                    self.logger.info(f"   📋 KOSDAQ 예시 {i+1}: {code} - {name}")
                    
            except Exception as e:
                self.logger.warning(f"⚠️ pykrx - KOSDAQ 조회 실패: {e}")
                if len(all_stocks) == 0:
                    raise e
            
            # KONEX 종목도 조회 (선택사항)
            try:
                self.logger.info("📊 pykrx - KONEX 종목 조회 중...")
                konex_tickers = stock.get_market_ticker_list(today, market="KONEX")
                
                konex_stocks = []
                for ticker in konex_tickers:
                    try:
                        name = stock.get_market_ticker_name(ticker)
                        if name and len(ticker) == 6:
                            konex_stocks.append((ticker, name))
                    except Exception:
                        continue
                
                all_stocks.extend(konex_stocks)
                self.logger.info(f"✅ pykrx - KONEX 종목 {len(konex_stocks)}개 조회 완료")
                    
            except Exception as e:
                self.logger.debug(f"⚠️ pykrx - KONEX 조회 실패: {e}")
                # KONEX는 선택사항이므로 실패해도 무시
            
            if len(all_stocks) == 0:
                raise Exception("pykrx로 종목을 조회할 수 없습니다.")
            
            # 중복 제거 (혹시 있을 경우)
            unique_stocks = list(set(all_stocks))
            
            self.logger.info(f"📊 pykrx - 총 {len(unique_stocks)}개 종목 조회 완료")
            return unique_stocks
            
        except ImportError:
            raise ImportError("pykrx 라이브러리가 설치되지 않았습니다.")
        except Exception as e:
            raise Exception(f"pykrx 종목 조회 실패: {e}")
    
    async def get_enhanced_stock_info(self, symbol: str) -> Optional[Dict]:
        """pykrx를 활용한 향상된 종목 정보 조회 - StockData 반환"""
        try:
            # 기본 KIS API 정보 조회
            kis_info = await self.get_stock_info(symbol)
            if not kis_info:
                self.logger.debug(f"⚠️ {symbol} KIS API 정보 조회 실패")
                return None
            
            # pykrx로 추가 정보 조회
            try:
                from pykrx import stock
                from datetime import datetime, timedelta
                
                # 조회 날짜 결정 (주말/장 시간 고려)
                now = datetime.now()
                if now.weekday() >= 5:  # 주말
                    days_back = now.weekday() - 4  # 금요일로
                    date = now - timedelta(days=days_back)
                else:
                    date = now
                
                today = date.strftime("%Y%m%d")
                
                # 시가총액 등 기본정보
                try:
                    market_cap_df = stock.get_market_cap(today, market="ALL")
                    if symbol in market_cap_df.index:
                        market_info = market_cap_df.loc[symbol]
                        
                        # pykrx 정보로 KIS 정보 보완/업데이트
                        pykrx_market_cap = float(market_info['시가총액']) / 100000000  # 억원 단위
                        pykrx_volume = int(market_info['거래량'])
                        pykrx_trading_value = float(market_info['거래대금']) / 1000000  # 백만원 단위
                        pykrx_shares = int(market_info['상장주식수'])
                        
                        # KIS 정보가 부정확하면 pykrx 정보로 대체
                        if kis_info['market_cap'] <= 0 and pykrx_market_cap > 0:
                            kis_info['market_cap'] = pykrx_market_cap
                        
                        if kis_info['volume'] <= 0 and pykrx_volume > 0:
                            kis_info['volume'] = pykrx_volume
                        
                        if kis_info['trading_value'] <= 0 and pykrx_trading_value > 0:
                            kis_info['trading_value'] = pykrx_trading_value
                        
                        # 추가 정보 업데이트
                        kis_info['shares_outstanding'] = pykrx_shares
                        
                        self.logger.debug(f"✅ {symbol} pykrx 정보로 보완 완료")
                        
                except Exception as e:
                    self.logger.debug(f"⚠️ {symbol} pykrx 시가총액 정보 조회 실패: {e}")
                
                # 펀더멘털 정보 (PER, PBR 등)
                try:
                    fundamental_df = stock.get_market_fundamental(today, market="ALL")
                    if symbol in fundamental_df.index:
                        fundamental_info = fundamental_df.loc[symbol]
                        
                        per = float(fundamental_info['PER']) if fundamental_info['PER'] > 0 else None
                        pbr = float(fundamental_info['PBR']) if fundamental_info['PBR'] > 0 else None
                        eps = float(fundamental_info['EPS']) if fundamental_info['EPS'] > 0 else None
                        bps = float(fundamental_info['BPS']) if fundamental_info['BPS'] > 0 else None
                        
                        # KIS 정보가 없으면 pykrx 정보로 대체
                        if not kis_info.get('pe_ratio') and per:
                            kis_info['pe_ratio'] = per
                        
                        if not kis_info.get('pbr') and pbr:
                            kis_info['pbr'] = pbr
                        
                        if not kis_info.get('eps') and eps:
                            kis_info['eps'] = eps
                        
                        if not kis_info.get('bps') and bps:
                            kis_info['bps'] = bps
                        
                        self.logger.debug(f"✅ {symbol} pykrx 펀더멘털 정보로 보완 완료")
                        
                except Exception as e:
                    self.logger.debug(f"⚠️ {symbol} pykrx 펀더멘털 정보 조회 실패: {e}")
                    
            except ImportError:
                self.logger.debug("⚠️ pykrx 라이브러리가 없어 기본 KIS 정보만 사용")
            except Exception as e:
                self.logger.debug(f"⚠️ {symbol} pykrx 정보 조회 실패: {e}")
            
            # StockData 객체 생성하여 반환
            stock_data = self.create_stock_data(kis_info)
            return stock_data
            
        except Exception as e:
            self.logger.debug(f"⚠️ {symbol} 향상된 정보 조회 실패: {e}")
            # 기본 정보라도 반환 시도
            try:
                basic_info = await self.get_stock_info(symbol)
                if basic_info:
                    return self.create_stock_data(basic_info)
            except:
                pass
            return None
    
    async def _get_stock_list_krx_web(self) -> List[Tuple[str, str]]:
        """KRX 웹사이트에서 직접 종목 리스트 조회"""
        try:
            import pandas as pd
            self.logger.info("📊 KRX 웹사이트에서 종목 리스트 조회 중...")
            
            all_stocks = []
            
            # KOSPI 조회
            try:
                kospi_url = 'http://kind.krx.co.kr/corpgeneral/corpList.do?currentPageSize=5000&pageIndex=1&method=download&searchType=13&marketType=stockMkt'
                kospi_df = pd.read_html(kospi_url, header=0, converters={'종목코드': lambda x: f"{x:06d}"})[0]
                
                for _, row in kospi_df.iterrows():
                    code = str(row['종목코드']).zfill(6)
                    name = str(row['회사명']).strip()
                    if code and name:
                        all_stocks.append((code, name))
                
                self.logger.info(f"✅ KRX 웹 - KOSPI 종목 {len(all_stocks)}개 조회 완료")
            except Exception as e:
                self.logger.warning(f"⚠️ KRX 웹 - KOSPI 조회 실패: {e}")
            
            # KOSDAQ 조회
            try:
                kosdaq_url = 'http://kind.krx.co.kr/corpgeneral/corpList.do?currentPageSize=5000&pageIndex=1&method=download&searchType=13&marketType=kosdaqMkt'
                kosdaq_df = pd.read_html(kosdaq_url, header=0, converters={'종목코드': lambda x: f"{x:06d}"})[0]
                
                kosdaq_start = len(all_stocks)
                for _, row in kosdaq_df.iterrows():
                    code = str(row['종목코드']).zfill(6)
                    name = str(row['회사명']).strip()
                    if code and name:
                        all_stocks.append((code, name))
                
                kosdaq_count = len(all_stocks) - kosdaq_start
                self.logger.info(f"✅ KRX 웹 - KOSDAQ 종목 {kosdaq_count}개 조회 완료")
            except Exception as e:
                self.logger.warning(f"⚠️ KRX 웹 - KOSDAQ 조회 실패: {e}")
                if len(all_stocks) == 0:
                    raise e
            
            if len(all_stocks) == 0:
                raise Exception("KRX 웹사이트에서 종목을 조회할 수 없습니다.")
            
            self.logger.info(f"📊 KRX 웹 - 총 {len(all_stocks)}개 종목 조회 완료")
            return all_stocks
            
        except Exception as e:
            raise Exception(f"KRX 웹사이트 종목 조회 실패: {e}")
    
    async def _get_stock_list_python_kis(self) -> List[Tuple[str, str]]:
        """python-kis 라이브러리를 사용한 종목 리스트 조회"""
        try:
            from pykis import PyKis
            self.logger.info("✅ python-kis 라이브러리 로드 성공")
            
            # 환경변수에서 KIS 정보 가져오기
            kis = PyKis(
                id=os.getenv("KIS_HTS_ID", ""),
                account=os.getenv("KIS_ACCOUNT", ""),
                appkey=self.app_key,
                secretkey=self.app_secret,
                virtual=self.is_virtual
            )
            
            # python-kis의 종목 리스트 조회 방법이 있다면 사용
            # (실제 python-kis API 문서를 확인해야 정확한 방법을 알 수 있음)
            self.logger.warning("⚠️ python-kis의 종목 리스트 조회 방법을 구현해야 합니다.")
            raise Exception("python-kis 종목 리스트 조회 미구현")
            
        except ImportError:
            raise ImportError("python-kis 라이브러리가 설치되지 않았습니다.")
        except Exception as e:
            raise Exception(f"python-kis 종목 조회 실패: {e}")
    
    async def _get_stock_list_direct_api(self) -> List[Tuple[str, str]]:
        """직접 API 호출로 종목 리스트 조회 (kis-client 실패 시 대체)"""
        try:
            self.logger.info("📋 직접 API 호출로 종목 리스트 조회 시도...")
            
            if not await self._check_token_validity():
                raise Exception("토큰이 유효하지 않습니다.")
            
            all_stocks = []
            
            # KOSPI 종목 조회
            try:
                kospi_stocks = await self._get_market_stocks("J")
                all_stocks.extend(kospi_stocks)
                self.logger.info(f"✅ 직접 API - KOSPI 종목 {len(kospi_stocks)}개 조회 완료")
            except Exception as e:
                self.logger.error(f"❌ 직접 API - KOSPI 종목 조회 실패: {e}")
                raise Exception(f"직접 API KOSPI 종목 리스트 조회 실패: {e}")
            
            # KOSDAQ 종목 조회
            try:
                kosdaq_stocks = await self._get_market_stocks("Q")
                all_stocks.extend(kosdaq_stocks)
                self.logger.info(f"✅ 직접 API - KOSDAQ 종목 {len(kosdaq_stocks)}개 조회 완료")
            except Exception as e:
                self.logger.error(f"❌ 직접 API - KOSDAQ 종목 조회 실패: {e}")
                # KOSPI는 성공했다면 KOSDAQ 실패는 경고만 출력
                if len(all_stocks) == 0:
                    raise Exception(f"직접 API 모든 시장 종목 리스트 조회 실패: {e}")
                else:
                    self.logger.warning(f"⚠️ 직접 API - KOSDAQ 종목 조회 실패하였으나 KOSPI 종목은 조회됨")
            
            if len(all_stocks) == 0:
                raise Exception("직접 API로도 종목 리스트를 조회할 수 없습니다.")
            
            self.logger.info(f"📊 직접 API - 총 {len(all_stocks)}개 종목 조회 완료")
            return all_stocks
            
        except Exception as e:
            self.logger.error(f"❌ 직접 API 종목 리스트 조회 실패: {e}")
            raise e
    
    async def _get_market_stocks(self, market_div: str) -> List[Tuple[str, str]]:
        """특정 시장의 종목 리스트 조회"""
        try:
            self.logger.info(f"📋 {market_div} 시장 종목 리스트 조회 시도...")
            
            # 여러 가능한 API 엔드포인트를 시도
            endpoints_to_try = [
                {
                    "url": f"{self.base_url}/uapi/domestic-stock/v1/quotations/inquire-member",
                    "tr_id": "FHKST130000C0",
                    "params": {
                        "FID_COND_MRKT_DIV_CODE": market_div,
                        "FID_INPUT_ISCD": "0000"
                    }
                },
                {
                    "url": f"{self.base_url}/uapi/domestic-stock/v1/quotations/inquire-daily-itemchartprice", 
                    "tr_id": "FHKST03010100",
                    "params": {
                        "FID_COND_MRKT_DIV_CODE": market_div,
                        "FID_INPUT_ISCD": "005930",  # 삼성전자로 테스트
                        "FID_PERIOD_DIV_CODE": "D"
                    }
                }
            ]
            
            last_error = None
            
            for i, endpoint in enumerate(endpoints_to_try):
                try:
                    self.logger.info(f"🔍 엔드포인트 {i+1}/{len(endpoints_to_try)} 시도: {endpoint['tr_id']}")
                    
                    headers = {
                        "tr_id": endpoint["tr_id"],
                        "custtype": "P"
                    }
                    headers.update(self.session.headers)
                    
                    async with self.session.get(endpoint["url"], params=endpoint["params"], headers=headers) as response:
                        response_text = await response.text()
                        
                        self.logger.info(f"📊 API 응답 상태: {response.status}")
                        self.logger.info(f"📄 API 응답 내용 (처음 500자): {response_text[:500]}")
                        
                        if response.status == 200:
                            try:
                                data = json.loads(response_text)
                                self.logger.info(f"📋 파싱된 JSON 구조: {list(data.keys()) if isinstance(data, dict) else type(data)}")
                                
                                if isinstance(data, dict):
                                    rt_cd = data.get('rt_cd', '')
                                    msg1 = data.get('msg1', '')
                                    self.logger.info(f"📊 RT_CD: '{rt_cd}', MSG1: '{msg1}'")
                                    
                                    if rt_cd == '0':
                                        # 성공적인 응답이면 종목 리스트 파싱 시도
                                        stocks = self._parse_stock_list(data)
                                        if stocks:
                                            self.logger.info(f"✅ {endpoint['tr_id']} 엔드포인트로 {len(stocks)}개 종목 조회 성공")
                                            return stocks
                                        else:
                                            self.logger.warning(f"⚠️ {endpoint['tr_id']} 응답은 성공했지만 종목 파싱 실패")
                                    else:
                                        self.logger.warning(f"⚠️ {endpoint['tr_id']} API 오류: {rt_cd} - {msg1}")
                                        last_error = f"API 오류: {rt_cd} - {msg1}"
                                
                            except json.JSONDecodeError as e:
                                self.logger.error(f"❌ JSON 파싱 실패: {e}")
                                self.logger.error(f"❌ 원본 응답: {response_text}")
                                last_error = f"JSON 파싱 실패: {e}"
                        
                        elif response.status == 429:
                            self.logger.warning("⚠️ API 호출 제한. 잠시 대기...")
                            await asyncio.sleep(2)
                            last_error = "API 호출 제한"
                        
                        else:
                            self.logger.error(f"❌ HTTP 오류: {response.status}")
                            self.logger.error(f"❌ 응답 내용: {response_text}")
                            last_error = f"HTTP 오류: {response.status}"
                    
                    # 다음 시도 전 대기
                    await asyncio.sleep(1)
                    
                except Exception as e:
                    self.logger.error(f"❌ 엔드포인트 {endpoint['tr_id']} 시도 중 오류: {e}")
                    last_error = str(e)
                    continue
            
            # 모든 엔드포인트 실패
            raise Exception(f"모든 종목 리스트 API 엔드포인트 실패. 마지막 오류: {last_error}")
                    
        except Exception as e:
            self.logger.error(f"❌ {market_div} 시장 종목 조회 오류: {e}")
            raise e
    
    def _parse_stock_list(self, data: Dict) -> List[Tuple[str, str]]:
        """종목 리스트 파싱 - 여러 API 응답 형식 지원"""
        try:
            self.logger.info(f"📊 종목 리스트 파싱 시작...")
            self.logger.info(f"📋 데이터 구조: {list(data.keys()) if isinstance(data, dict) else type(data)}")
            
            rt_cd = data.get('rt_cd', '')
            if rt_cd != '0':
                msg = data.get('msg1', 'Unknown error')
                raise Exception(f"API 응답 오류: {rt_cd} - {msg}")
            
            # 다양한 output 형식 시도
            output_candidates = [
                data.get('output', []),
                data.get('output1', []), 
                data.get('output2', []),
                data.get('OutBlock_1', [])
            ]
            
            output = None
            for candidate in output_candidates:
                if candidate:
                    output = candidate
                    break
            
            if not output:
                self.logger.warning("⚠️ API 응답에 종목 데이터가 없습니다.")
                self.logger.info(f"📄 전체 응답 구조: {json.dumps(data, indent=2, ensure_ascii=False)[:1000]}")
                
                # 단일 종목 응답인 경우 (테스트용)
                if 'output' in data and isinstance(data['output'], dict):
                    single_output = data['output']
                    symbol = single_output.get('stck_shrt_cd', '').strip()
                    name = single_output.get('hts_kor_isnm', '').strip()
                    
                    if symbol and name and len(symbol) == 6:
                        self.logger.info(f"📊 단일 종목 감지: {symbol} - {name}")
                        return [(symbol, name)]
                
                raise Exception("API 응답에 종목 데이터가 없습니다.")
            
            if not isinstance(output, list):
                self.logger.warning(f"⚠️ output이 리스트가 아님: {type(output)}")
                # output이 딕셔너리인 경우 리스트로 변환 시도
                if isinstance(output, dict):
                    output = [output]
                else:
                    raise Exception(f"예상치 못한 output 형식: {type(output)}")
            
            self.logger.info(f"📊 output 리스트 크기: {len(output)}")
            
            if len(output) > 0:
                self.logger.info(f"📋 첫 번째 항목 구조: {list(output[0].keys()) if isinstance(output[0], dict) else type(output[0])}")
            
            stocks = []
            
            # 다양한 필드명 시도
            symbol_fields = ['stck_shrt_cd', 'stck_cd', 'symbol', 'code']
            name_fields = ['hts_kor_isnm', 'stck_name', 'name', 'hts_kor_nm']
            
            for i, item in enumerate(output):
                if not isinstance(item, dict):
                    continue
                
                # 첫 번째 항목의 모든 필드 출력 (디버깅용)
                if i == 0:
                    self.logger.info(f"📋 첫 번째 항목 전체 필드: {list(item.keys())}")
                    self.logger.info(f"📄 첫 번째 항목 내용: {json.dumps(item, ensure_ascii=False)}")
                
                symbol = None
                name = None
                
                # 종목 코드 찾기
                for field in symbol_fields:
                    if field in item and item[field]:
                        symbol = str(item[field]).strip()
                        if len(symbol) == 6 and symbol.isdigit():
                            break
                
                # 종목명 찾기
                for field in name_fields:
                    if field in item and item[field]:
                        name = str(item[field]).strip()
                        if name:
                            break
                
                if symbol and name and len(symbol) == 6:
                    stocks.append((symbol, name))
                    if len(stocks) <= 5:  # 처음 5개만 로그 출력
                        self.logger.info(f"📊 종목 추가: {symbol} - {name}")
                elif i < 10:  # 처음 10개 항목 중 실패한 것만 로그
                    self.logger.debug(f"⚠️ 종목 파싱 실패 - symbol: '{symbol}', name: '{name}'")
            
            if len(stocks) == 0:
                self.logger.error("❌ 파싱된 종목이 없습니다.")
                raise Exception("파싱된 종목이 없습니다. API 응답 형식을 확인하세요.")
            
            self.logger.info(f"✅ 총 {len(stocks)}개 종목 파싱 완료")
            return stocks
            
        except Exception as e:
            self.logger.error(f"❌ 종목 리스트 파싱 오류: {e}")
            raise e
    
    async def get_stock_info(self, symbol: str) -> Optional[Dict]:
        """종목 기본 정보 조회"""
        try:
            if not await self._check_token_validity():
                raise Exception("토큰이 유효하지 않습니다.")
            
            # KIS API 호출 - 종목 기본 정보 (실시간 시세)
            url = f"{self.base_url}/uapi/domestic-stock/v1/quotations/inquire-price"
            
            params = {
                "FID_COND_MRKT_DIV_CODE": "J",
                "FID_INPUT_ISCD": symbol
            }
            
            headers = {
                "tr_id": "FHKST01010100",
                "custtype": "P"
            }
            headers.update(self.session.headers)
            
            async with self.session.get(url, params=params, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    return self._parse_stock_info(data, symbol)
                elif response.status == 401:
                    self.logger.warning(f"⚠️ {symbol} 인증 오류. 토큰 재발급 시도")
                    if await self._get_access_token():
                        return await self.get_stock_info(symbol)  # 재시도
                    return None
                elif response.status == 429:
                    self.logger.warning("⚠️ API 호출 제한. 잠시 대기...")
                    await asyncio.sleep(1)
                    return None
                else:
                    error_text = await response.text()
                    self.logger.debug(f"⚠️ {symbol} 정보 조회 실패: {response.status}, {error_text}")
                    return None
                    
        except Exception as e:
            self.logger.debug(f"⚠️ {symbol} 정보 조회 오류: {e}")
            return None
    
    def _parse_stock_info(self, data: Dict, symbol: str) -> Optional[Dict]:
        """KIS API 응답 파싱"""
        try:
            # API 응답 상태 확인
            rt_cd = data.get('rt_cd', '')
            if rt_cd != '0':
                msg = data.get('msg1', 'Unknown error')
                self.logger.debug(f"⚠️ {symbol} API 응답 오류: {rt_cd} - {msg}")
                return None
            
            output = data.get('output', {})
            if not output:
                self.logger.debug(f"⚠️ {symbol} 응답 데이터 없음")
                return None
            
            # 현재가 파싱
            current_price = 0
            price_fields = ['stck_prpr', 'stck_prdy_clpr', 'stck_oprc']
            
            for field in price_fields:
                try:
                    price_str = output.get(field, '0')
                    if price_str and str(price_str).strip() != '' and str(price_str) != '0':
                        current_price = float(price_str)
                        break
                except (ValueError, TypeError):
                    continue
            
            if current_price <= 0:
                self.logger.debug(f"⚠️ {symbol} 유효하지 않은 가격 데이터")
                return None
            
            # 종목명 파싱
            name = output.get('hts_kor_isnm', '').strip()
            if not name:
                name = f'종목{symbol}'
            
            # 기타 데이터 파싱
            volume = self._safe_int_parse(output.get('acml_vol', '0'))
            trading_value = self._safe_float_parse(output.get('acml_tr_pbmn', '0')) / 1000000
            market_cap = self._safe_float_parse(output.get('hts_avls', '0')) / 100000000
            change_rate = self._safe_float_parse(output.get('prdy_ctrt', '0'))
            
            # 52주 고저가
            high_52w = self._safe_float_parse(output.get('w52_hgpr', '0'))
            low_52w = self._safe_float_parse(output.get('w52_lwpr', '0'))
            
            if high_52w <= 0:
                high_52w = current_price * 1.5
            if low_52w <= 0:
                low_52w = current_price * 0.7
            
            # PER, PBR
            pe_ratio = self._safe_float_parse(output.get('per', '0'))
            pbr = self._safe_float_parse(output.get('pbr', '0'))
            
            if pe_ratio <= 0:
                pe_ratio = None
            if pbr <= 0:
                pbr = None
            
            # 시장 구분
            market_div = output.get('mrkt_div_cd', '')
            market = "KOSPI" if market_div == "J" else "KOSDAQ"
            
            result = {
                "symbol": symbol,
                "name": name,
                "market": market,
                "sector": "기타",
                "current_price": current_price,
                "change_rate": change_rate,
                "volume": volume,
                "trading_value": trading_value,
                "market_cap": market_cap,
                "high_52w": high_52w,
                "low_52w": low_52w,
                "pe_ratio": pe_ratio,
                "pbr": pbr
            }
            
            self.logger.debug(f"✅ {symbol} ({name}) 파싱 완료 - 가격: {current_price:,.0f}원, 시총: {market_cap:.0f}억")
            return result
            
        except Exception as e:
            self.logger.warning(f"⚠️ {symbol} 데이터 파싱 오류: {e}")
            return None
    
    def _safe_int_parse(self, value, default: int = 0) -> int:
        """안전한 정수 파싱"""
        import math
        
        if value is None or value == 'None':
            return default
        
        try:
            if isinstance(value, (int, float)):
                # NaN 체크 (pandas 없이)
                if math.isnan(value) or math.isinf(value):
                    return default
                return int(value)
            
            value_str = str(value).strip()
            if not value_str or value_str.lower() in ['nan', 'none', 'null', '', 'nat', 'inf', '-inf']:
                return default
            
            # 콤마 제거
            value_str = value_str.replace(',', '')
            
            # 소수점이 있는 경우
            if '.' in value_str:
                float_val = float(value_str)
                if math.isnan(float_val) or math.isinf(float_val):
                    return default
                return int(float_val)
            else:
                return int(value_str)
                
        except (ValueError, TypeError, OverflowError) as e:
            self.logger.debug(f"⚠️ 정수 파싱 실패 '{value}' (타입: {type(value)}): {e}, 기본값 {default} 사용")
            return default
    
    def _safe_float_parse(self, value, default: float = 0.0) -> float:
        """안전한 실수 파싱"""
        import math
        
        if value is None or value == 'None':
            return default
        
        try:
            if isinstance(value, (int, float)):
                # NaN 체크 (pandas 없이)
                if math.isnan(value) or math.isinf(value):
                    return default
                return float(value)
            
            value_str = str(value).strip()
            if not value_str or value_str.lower() in ['nan', 'none', 'null', '', 'nat', 'inf', '-inf']:
                return default
            
            # 콤마 제거
            value_str = value_str.replace(',', '')
            
            float_val = float(value_str)
            if math.isnan(float_val) or math.isinf(float_val):
                return default
            return float_val
            
        except (ValueError, TypeError, OverflowError) as e:
            self.logger.debug(f"⚠️ 실수 파싱 실패 '{value}' (타입: {type(value)}): {e}, 기본값 {default} 사용")
            return default
    
    def _meets_filter_criteria(self, stock_info: Dict) -> bool:
        """필터링 조건 검사 - 장시간 고려 개선"""
        try:
            # 현재 시간 체크
            from datetime import datetime, time
            now = datetime.now()
            market_open = time(9, 0)  # 오전 9시
            market_close = time(15, 30)  # 오후 3시 30분
            is_market_time = market_open <= now.time() <= market_close and now.weekday() < 5
            
            # Config에서 필터링 조건 가져오기
            min_price = self.config.trading.MIN_PRICE
            max_price = self.config.trading.MAX_PRICE
            min_volume = self.config.trading.MIN_VOLUME
            min_market_cap = self.config.trading.MIN_MARKET_CAP
            
            # 장 시간 외에는 거래량 조건 완화
            if not is_market_time:
                min_volume = max(100, min_volume // 10)  # 1/10로 완화하되 최소 100주
            
            current_price = stock_info.get('current_price', 0)
            volume = stock_info.get('volume', 0)
            market_cap = stock_info.get('market_cap', 0)
            
            self.logger.debug(f"🔍 {stock_info['symbol']} 검사 (장시간: {is_market_time}):")
            self.logger.debug(f"   💰 현재가: {current_price:,.0f}원 (조건: {min_price:,}~{max_price:,})")
            self.logger.debug(f"   📊 거래량: {volume:,}주 (최소: {min_volume:,})")
            self.logger.debug(f"   🏢 시가총액: {market_cap:.0f}억원 (최소: {min_market_cap:,})")
            
            # 가격 조건 확인
            if current_price < min_price or current_price > max_price:
                self.logger.debug(f"❌ {stock_info['symbol']} 가격 조건 불충족: {current_price:,.0f}원")
                return False
            
            # 거래량 조건 확인
            if volume < min_volume:
                self.logger.debug(f"❌ {stock_info['symbol']} 거래량 조건 불충족: {volume:,}주 (장시간외 완화: {not is_market_time})")
                return False
            
            # 시가총액 조건 확인
            if market_cap < min_market_cap:
                self.logger.debug(f"❌ {stock_info['symbol']} 시가총액 조건 불충족: {market_cap:.0f}억원")
                return False
            
            # 추가 필터링 조건들
            name = stock_info.get('name', '')
            exclude_keywords = ['관리', '정리매매', '투자주의', '투자경고', '스팩', 'SPAC', '우선주', '지주회사']
            if any(keyword in name for keyword in exclude_keywords):
                self.logger.debug(f"❌ {stock_info['symbol']} 제외 키워드 포함: {name}")
                return False
            
            # 거래대금 조건 (장시간에 따라 조정)
            trading_value = stock_info.get('trading_value', 0)
            min_trading_value = 100 if is_market_time else 50  # 장시간 외에는 완화
            if trading_value < min_trading_value:
                self.logger.debug(f"❌ {stock_info['symbol']} 거래대금 조건 불충족: {trading_value:.0f}백만원 (최소: {min_trading_value}백만원)")
                return False
            
            self.logger.debug(f"✅ {stock_info['symbol']} 모든 조건 통과!")
            return True
            
        except Exception as e:
            self.logger.warning(f"⚠️ {stock_info.get('symbol', 'UNKNOWN')} 필터링 조건 검사 오류: {e}")
            return False
    
    async def get_filtered_stocks(self, limit: int = 50, use_cache: bool = True) -> List[Tuple[str, str]]:
        """필터링된 종목 리스트 반환 - 종목명 캐시 추가"""
        try:
            # 먼저 pykrx 방식 시도
            try:
                result = await self.get_filtered_stocks_pykrx(limit, use_cache)
                # pykrx 결과에 종목명 캐시 생성
                if result:
                    self._cache_stock_names(result)
                return result
            except Exception as e:
                self.logger.warning(f"⚠️ pykrx 방식 실패, KIS API 방식으로 대체: {e}")
            
            # pykrx 실패 시 기존 KIS API 방식 사용
            self.logger.info(f"🔍 KIS API 기반 종목 필터링 시작 (목표: {limit}개)")
            
            # 캐시 확인
            if use_cache:
                cached_stocks = await self._get_cached_filtered_stocks(limit)
                if cached_stocks:
                    self.logger.info(f"✅ 캐시된 필터링 결과 사용: {len(cached_stocks)}개 종목")
                    self._cache_stock_names(cached_stocks)
                    return cached_stocks
            
            # 전체 종목 리스트 조회
            all_stocks = await self.get_stock_list()
            self.logger.info(f"📊 전체 종목 수: {len(all_stocks)}개")
            
            # 샘플링으로 효율성 확보
            sample_size = min(500, len(all_stocks))
            import random
            sample_stocks = random.sample(all_stocks, sample_size)
            self.logger.info(f"🎯 샘플링 필터링: {sample_size}개 종목 검사")
            
            filtered_stocks = []
            failed_count = 0
            checked_count = 0
            
            for symbol, name in sample_stocks:
                if len(filtered_stocks) >= limit:
                    break
                
                try:
                    checked_count += 1
                    
                    if checked_count % 50 == 0:
                        self.logger.info(f"[{checked_count}/{sample_size}] 진행률: {checked_count/sample_size*100:.1f}% (현재까지 {len(filtered_stocks)}개 선정)")
                    
                    stock_info = await self.get_stock_info(symbol)
                    if not stock_info:
                        failed_count += 1
                        if failed_count > 20:
                            self.logger.warning("⚠️ 연속 실패가 많아 필터링을 중단합니다.")
                            break
                        continue
                    
                    # 필터링 조건 확인
                    if self._meets_filter_criteria(stock_info):
                        filtered_stocks.append((symbol, name))  # 원본 종목명 사용
                        self.logger.info(f"✅ {symbol} ({name}) 필터링 통과")
                        failed_count = 0
                    
                    await asyncio.sleep(0.05)
                    
                except Exception as e:
                    self.logger.debug(f"⚠️ {symbol} 필터링 중 오류: {e}")
                    failed_count += 1
                    continue
            
            # 결과 캐시에 저장
            if filtered_stocks:
                self._cache_stock_names(filtered_stocks)
                await self._cache_filtered_stocks(filtered_stocks)
            
            self.logger.info(f"✅ KIS API 필터링 완료: {len(filtered_stocks)}개 종목 선정")
            
            if len(filtered_stocks) == 0:
                self.logger.warning("⚠️ 필터링 조건을 만족하는 종목이 없습니다.")
                fallback_stocks = await self._get_major_stocks_as_fallback(limit)
                self._cache_stock_names(fallback_stocks)
                return fallback_stocks
            
            return filtered_stocks
            
        except Exception as e:
            self.logger.error(f"❌ 종목 필터링 실패: {e}")
            fallback_stocks = await self._get_major_stocks_as_fallback(limit)
            self._cache_stock_names(fallback_stocks)
            return fallback_stocks
    # 2. 안전한 메서드 호출을 위한 헬퍼 함수
    async def safe_get_filtered_stocks(collector, limit: int = 50):
        """KISCollector에서 안전하게 필터링된 종목 조회"""
        try:
            if hasattr(collector, 'get_filtered_stocks'):
                return await collector.get_filtered_stocks(limit)
            elif hasattr(collector, 'get_filtered_stocks_pykrx'):
                return await collector.get_filtered_stocks_pykrx(limit)
            else:
                # 기본 종목 리스트 반환
                all_stocks = await collector.get_stock_list()
                return all_stocks[:limit]
        except Exception as e:
            collector.logger.error(f"❌ 안전한 종목 조회 실패: {e}")
            # 최후의 수단
            return [("005930", "삼성전자"), ("000660", "SK하이닉스"), ("035420", "NAVER")]
    def check_collector_methods(collector):
        """KISCollector 필수 메서드 존재 여부 확인"""
        required_methods = ['get_stock_list', 'get_stock_info', '_meets_filter_criteria']
        missing = [m for m in required_methods if not hasattr(collector, m)]
        
        if missing:
            collector.logger.error(f"❌ 누락된 메서드: {missing}")
            return False
        
        collector.logger.info("✅ 필수 메서드 모두 존재")
        return True
    
    
    async def get_filtered_stocks_pykrx(self, limit: int = 50, use_cache: bool = True) -> List[Tuple[str, str]]:
        """pykrx를 활용한 효율적인 종목 필터링 - 경고 수정"""
        try:
            self.logger.info(f"🔍 pykrx 기반 종목 필터링 시작 (목표: {limit}개)")
            
            # 현재 시간 체크
            from datetime import datetime, time, timedelta
            now = datetime.now()
            market_open = time(9, 0)
            market_close = time(15, 30)
            is_market_time = market_open <= now.time() <= market_close
            is_weekday = now.weekday() < 5
            
            # 캐시 확인
            if use_cache:
                cached_stocks = await self._get_cached_filtered_stocks(limit)
                if cached_stocks:
                    self.logger.info(f"✅ 캐시된 필터링 결과 사용: {len(cached_stocks)}개 종목")
                    return cached_stocks
            
            # pykrx 데이터 조회
            from pykrx import stock
            import pandas as pd
            
            # 조회 날짜 결정
            if not is_weekday or (is_weekday and now.time() < market_open):
                date = now
                while date.weekday() >= 5:
                    date = date - timedelta(days=1)
                if is_weekday and now.time() < market_open:
                    date = date - timedelta(days=1)
                date_str = date.strftime("%Y%m%d")
                self.logger.info(f"📅 전 거래일 데이터 사용: {date_str}")
            else:
                date_str = now.strftime("%Y%m%d")
                self.logger.info(f"📅 당일 데이터 사용: {date_str}")
            
            # 필터링 조건
            min_price = self.config.trading.MIN_PRICE
            max_price = self.config.trading.MAX_PRICE
            min_volume = self.config.trading.MIN_VOLUME
            min_market_cap = self.config.trading.MIN_MARKET_CAP
            
            if not is_market_time:
                min_volume = max(100, min_volume // 10)
                self.logger.info(f"📊 장 시간 외로 거래량 조건 완화: {min_volume:,}주")
            
            all_filtered_stocks = []
            
            # KOSPI와 KOSDAQ 각각 처리
            for market in ["KOSPI", "KOSDAQ"]:
                try:
                    self.logger.info(f"📊 {market} 시장 필터링 중...")
                    
                    # 데이터 조회 시도
                    try:
                        df = stock.get_market_cap(date_str, market=market)
                    except Exception as e:
                        self.logger.warning(f"⚠️ {market} {date_str} 데이터 조회 실패, 이전 날짜 시도: {e}")
                        # 이전 날짜들 시도
                        for days_back in range(1, 8):
                            try:
                                fallback_date = (datetime.strptime(date_str, "%Y%m%d") - timedelta(days=days_back)).strftime("%Y%m%d")
                                df = stock.get_market_cap(fallback_date, market=market)
                                self.logger.info(f"✅ {market} {fallback_date} 데이터로 대체 성공")
                                break
                            except:
                                continue
                        else:
                            self.logger.error(f"❌ {market} 모든 날짜 시도 실패")
                            continue
                    
                    # 인덱스를 컬럼으로 변환 (copy 생성)
                    df = df.reset_index().copy()  # copy()로 SettingWithCopyWarning 방지
                    df.rename(columns={'티커': '종목코드'}, inplace=True)
                    
                    # 종목명 추가
                    df["종목명"] = df["종목코드"].apply(lambda x: stock.get_market_ticker_name(x))
                    
                    # 데이터 타입 변환 및 NaN 처리
                    df["종가"] = pd.to_numeric(df["종가"], errors='coerce').fillna(0)
                    df["거래량"] = pd.to_numeric(df["거래량"], errors='coerce').fillna(0)
                    df["시가총액"] = pd.to_numeric(df["시가총액"], errors='coerce').fillna(0)
                    
                    # 시가총액 단위 변환
                    df["시가총액(억원)"] = df["시가총액"] // 100000000
                    
                    # 1차 필터링 (copy() 사용으로 경고 방지)
                    filtered_df = df[
                        (df["종가"] >= min_price) & 
                        (df["종가"] <= max_price) & 
                        (df["거래량"] >= min_volume) & 
                        (df["시가총액(억원)"] >= min_market_cap) &
                        (df["종목명"].notna()) &
                        (df["종가"] > 0) &
                        (~df["종목명"].str.contains('관리|정리매매|투자주의|투자경고|스팩|SPAC|지주회사', na=False))
                    ].copy()  # copy()로 새로운 DataFrame 생성
                    
                    # 거래대금 조건 (copy된 DataFrame에서 안전하게 수정)
                    min_trading_value = 100 if is_market_time else 50
                    filtered_df.loc[:, "거래대금(백만원)"] = (filtered_df["종가"] * filtered_df["거래량"]) / 1000000  # .loc 사용
                    filtered_df = filtered_df[filtered_df["거래대금(백만원)"] >= min_trading_value].copy()
                    
                    # 결과를 튜플 리스트로 변환
                    market_stocks = [(row["종목코드"], row["종목명"]) for _, row in filtered_df.iterrows()]
                    all_filtered_stocks.extend(market_stocks)
                    
                    self.logger.info(f"✅ {market} 필터링 완료: {len(market_stocks)}개 종목")
                    
                    # 처음 3개 종목 로그 출력
                    for i, (code, name) in enumerate(market_stocks[:3]):
                        try:
                            row_data = filtered_df[filtered_df["종목코드"] == code].iloc[0]
                            price = row_data["종가"]
                            volume = row_data["거래량"]
                            market_cap = row_data["시가총액(억원)"]
                            trading_value = row_data["거래대금(백만원)"]
                            self.logger.info(f"   📋 {market} 예시 {i+1}: {code} ({name})")
                            self.logger.info(f"       💰 가격: {price:,.0f}원, 📊 거래량: {volume:,}주")
                            self.logger.info(f"       🏢 시총: {market_cap:.0f}억원, 💵 거래대금: {trading_value:.0f}백만원")
                        except Exception as e:
                            self.logger.debug(f"⚠️ {code} 로그 출력 실패: {e}")
                    
                except Exception as e:
                    self.logger.warning(f"⚠️ {market} 시장 필터링 실패: {e}")
                    continue
            
            # 결과 제한 및 정렬
            if len(all_filtered_stocks) > limit:
                try:
                    # 시가총액 기준으로 정렬
                    sorted_stocks = []
                    for symbol, name in all_filtered_stocks:
                        try:
                            cap_info = stock.get_market_cap(date_str, market="ALL")
                            if symbol in cap_info.index:
                                market_cap = cap_info.loc[symbol, '시가총액'] / 100000000
                                sorted_stocks.append((symbol, name, market_cap))
                            else:
                                sorted_stocks.append((symbol, name, 0))
                        except:
                            sorted_stocks.append((symbol, name, 0))
                    
                    sorted_stocks.sort(key=lambda x: x[2], reverse=True)
                    all_filtered_stocks = [(s[0], s[1]) for s in sorted_stocks[:limit]]
                    
                except Exception:
                    all_filtered_stocks = all_filtered_stocks[:limit]
            
            # 캐시에 저장
            if all_filtered_stocks:
                await self._cache_filtered_stocks(all_filtered_stocks)
            
            self.logger.info(f"✅ pykrx 필터링 완료: 총 {len(all_filtered_stocks)}개 종목 선정")
            
            if len(all_filtered_stocks) == 0:
                self.logger.warning("⚠️ 필터링 조건을 만족하는 종목이 없습니다.")
                return await self._get_major_stocks_as_fallback(limit)
            
            return all_filtered_stocks
            
        except ImportError:
            self.logger.error("❌ pykrx 라이브러리가 설치되지 않았습니다.")
            return await self.get_filtered_stocks(limit, use_cache)
        except Exception as e:
            self.logger.error(f"❌ pykrx 필터링 실패: {e}")
            return await self.get_filtered_stocks(limit, use_cache)
    
    async def _get_cached_filtered_stocks(self, limit: int) -> List[Tuple[str, str]]:
        """캐시된 필터링 결과 조회 - 개선된 버전"""
        try:
            from datetime import datetime, timedelta
            
            cache_file = Path("data/filtered_stocks_cache.json")
            
            if not cache_file.exists():
                self.logger.debug("📚 캐시 파일이 없습니다.")
                return []
            
            with open(cache_file, 'r', encoding='utf-8') as f:
                cache_data = json.load(f)
            
            # 캐시 데이터 유효성 검사
            if not isinstance(cache_data, dict):
                self.logger.debug("📚 캐시 데이터 형식이 올바르지 않습니다.")
                return []
            
            cache_date = cache_data.get('date')
            cache_stocks = cache_data.get('stocks', [])
            
            if not cache_date or not cache_stocks:
                self.logger.debug("📚 캐시 데이터가 불완전합니다.")
                return []
            
            # 캐시 만료 검사
            now = datetime.now()
            today = now.strftime("%Y-%m-%d")
            
            # 주말이나 장 시작 전이면 전일 캐시도 허용
            is_weekend = now.weekday() >= 5
            is_before_market = now.time() < datetime.strptime("09:00", "%H:%M").time()
            
            valid_dates = [today]
            if is_weekend or is_before_market:
                yesterday = (now - timedelta(days=1)).strftime("%Y-%m-%d")
                valid_dates.append(yesterday)
                
                # 주말인 경우 금요일 캐시도 허용
                if is_weekend:
                    days_to_friday = now.weekday() - 4
                    friday = (now - timedelta(days=days_to_friday)).strftime("%Y-%m-%d")
                    valid_dates.append(friday)
            
            if cache_date in valid_dates:
                if len(cache_stocks) >= limit:
                    self.logger.info(f"📚 캐시 적중: {cache_date} 날짜의 {len(cache_stocks)}개 종목 사용")
                    return cache_stocks[:limit]
                else:
                    self.logger.debug(f"📚 캐시 종목 수 부족: {len(cache_stocks)}개 < {limit}개")
            else:
                self.logger.debug(f"📚 캐시 만료: {cache_date} not in {valid_dates}")
            
            return []
            
        except Exception as e:
            self.logger.debug(f"⚠️ 캐시 조회 실패: {e}")
            return []
    
    async def _cache_filtered_stocks(self, stocks: List[Tuple[str, str]]):
        """필터링 결과를 캐시에 저장 - 개선된 버전"""
        try:
            from datetime import datetime
            
            if not stocks:
                self.logger.debug("💾 저장할 종목이 없어 캐시를 생략합니다.")
                return
            
            cache_file = Path("data/filtered_stocks_cache.json")
            cache_file.parent.mkdir(exist_ok=True)
            
            cache_data = {
                'date': datetime.now().strftime("%Y-%m-%d"),
                'timestamp': datetime.now().isoformat(),
                'stocks': stocks,
                'count': len(stocks),
                'filter_conditions': {
                    'min_price': self.config.trading.MIN_PRICE,
                    'max_price': self.config.trading.MAX_PRICE,
                    'min_volume': self.config.trading.MIN_VOLUME,
                    'min_market_cap': self.config.trading.MIN_MARKET_CAP
                },
                'version': '2.0'  # 캐시 버전
            }
            
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(cache_data, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"💾 {len(stocks)}개 종목을 캐시에 저장했습니다.")
            
            # 종목 미리보기 로그
            preview_stocks = stocks[:3]
            for i, (symbol, name) in enumerate(preview_stocks):
                self.logger.debug(f"   📋 캐시된 종목 {i+1}: {symbol} - {name}")
            
        except Exception as e:
            self.logger.warning(f"⚠️ 캐시 저장 실패: {e}")
    
    async def _get_major_stocks_as_fallback(self, limit: int) -> List[Tuple[str, str]]:
        """주요 종목으로 대체 - 개선된 버전"""
        try:
            self.logger.info("🔄 주요 종목으로 대체합니다.")
            
            # 시가총액 순으로 정렬된 주요 종목들
            major_stocks = [
                # 대형주 (시가총액 상위)
                ("005930", "삼성전자"), ("000660", "SK하이닉스"), ("373220", "LG에너지솔루션"),
                ("207940", "삼성바이오로직스"), ("005490", "POSCO홀딩스"), ("035420", "NAVER"),
                ("006400", "삼성SDI"), ("051910", "LG화학"), ("068270", "셀트리온"),
                ("105560", "KB금융"), ("055550", "신한지주"), ("035720", "카카오"),
                
                # 중형주
                ("066570", "LG전자"), ("000270", "기아"), ("005380", "현대차"),
                ("012330", "현대모비스"), ("003550", "LG"), ("096770", "SK이노베이션"),
                ("034020", "두산에너빌리티"), ("009150", "삼성전기"), ("010950", "S-Oil"),
                ("086790", "하나금융지주"), ("316140", "우리금융지주"), ("003490", "대한항공"),
                
                # 성장주/테마주
                ("247540", "에코프로비엠"), ("086520", "에코프로"), ("042700", "한미반도체"),
                ("036570", "엔씨소프트"), ("251270", "넷마블"), ("302440", "SK바이오사이언스"),
                ("326030", "SK바이오팜"), ("000810", "삼성화재"), ("024110", "기업은행"),
                ("011070", "LG이노텍"), ("161390", "한국타이어앤테크놀로지"), ("034730", "SK"),
                
                # 추가 종목들
                ("009540", "HD한국조선해양"), ("000720", "현대건설"), ("047050", "포스코인터내셔널"),
                ("180640", "한진칼"), ("029780", "삼성카드"), ("015760", "한국전력"),
                ("090430", "아모레퍼시픽"), ("271560", "오리온"), ("097950", "CJ제일제당"),
                ("000120", "CJ대한통운"), ("139480", "이마트"), ("282330", "BGF리테일"),
                ("001040", "CJ"), ("004370", "농심"), ("001680", "대상"), ("011780", "금호석유"),
                ("010060", "OCI"), ("267250", "HD현대중공업"), ("010140", "삼성중공업")
            ]
            
            # 실제로 거래되는 종목인지 확인
            valid_stocks = []
            semaphore = asyncio.Semaphore(5)  # 동시 요청 제한
            
            async def check_stock_validity(symbol, name):
                async with semaphore:
                    try:
                        stock_info = await self.get_stock_info(symbol)
                        if stock_info and stock_info.get('current_price', 0) > 0:
                            # 기본적인 필터링 조건도 확인
                            if self._meets_filter_criteria(stock_info):
                                return (symbol, name, stock_info.get('market_cap', 0))
                            else:
                                # 조건을 만족하지 않아도 일단 포함 (대체 목적)
                                return (symbol, name, stock_info.get('market_cap', 0))
                        return None
                    except Exception as e:
                        self.logger.debug(f"⚠️ {symbol} 유효성 검사 실패: {e}")
                        return None
            
            # 병렬로 유효성 검사
            tasks = [check_stock_validity(symbol, name) for symbol, name in major_stocks]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # 결과 정리 및 시가총액 순 정렬
            valid_results = []
            for result in results:
                if result and not isinstance(result, Exception) and result is not None:
                    valid_results.append(result)
            
            # 시가총액 기준 내림차순 정렬
            valid_results.sort(key=lambda x: x[2], reverse=True)
            valid_stocks = [(symbol, name) for symbol, name, _ in valid_results[:limit]]
            
            if len(valid_stocks) == 0:
                # 정말 최후의 수단 - 검증 없이 주요 종목 반환
                self.logger.warning("⚠️ 유효성 검사 실패, 검증 없이 주요 종목 반환")
                valid_stocks = major_stocks[:limit]
            
            self.logger.info(f"🎯 주요 종목 {len(valid_stocks)}개 선정 완료")
            
            # 선정된 종목들 로그 출력
            for i, (symbol, name) in enumerate(valid_stocks[:5]):
                self.logger.info(f"   📋 대체 종목 {i+1}: {symbol} - {name}")
            
            return valid_stocks
            
        except Exception as e:
            self.logger.error(f"❌ 주요 종목 대체 실패: {e}")
            # 정말 최후의 수단
            basic_stocks = [
                ("005930", "삼성전자"), ("000660", "SK하이닉스"), ("035420", "NAVER"),
                ("207940", "삼성바이오로직스"), ("373220", "LG에너지솔루션")
            ]
            return basic_stocks[:min(limit, len(basic_stocks))]

    
    def create_stock_data(self, stock_info) -> StockData:
        """StockData 객체 생성 - pd 오류 수정"""
        import math
        
        try:
            # 입력 타입 확인
            self.logger.debug(f"🔍 StockData 생성 - 입력 타입: {type(stock_info)}")
            
            # None 체크
            if stock_info is None:
                self.logger.warning("⚠️ stock_info가 None입니다. 기본 StockData 생성")
                return StockData(
                    symbol='UNKNOWN',
                    name='알 수 없음',
                    current_price=0.0,
                    change_rate=0.0,
                    volume=0,
                    trading_value=0.0,
                    market_cap=0.0,
                    shares_outstanding=0,
                    high_52w=0.0,
                    low_52w=0.0
                )
            
            # 문자열인 경우
            if isinstance(stock_info, str):
                self.logger.debug(f"📋 {stock_info}: 종목코드만 전달됨")
                return StockData(
                    symbol=stock_info,
                    name=f'종목{stock_info}',
                    current_price=0.0,
                    change_rate=0.0,
                    volume=0,
                    trading_value=0.0,
                    market_cap=0.0,
                    shares_outstanding=0,
                    high_52w=0.0,
                    low_52w=0.0
                )
            
            # StockData 객체인 경우
            if isinstance(stock_info, StockData):
                return stock_info
            
            # 튜플인 경우
            if isinstance(stock_info, tuple) and len(stock_info) == 2:
                symbol, name = stock_info
                return StockData(
                    symbol=symbol,
                    name=name,
                    current_price=0.0,
                    change_rate=0.0,
                    volume=0,
                    trading_value=0.0,
                    market_cap=0.0,
                    shares_outstanding=0,
                    high_52w=0.0,
                    low_52w=0.0
                )
            
            # Dictionary가 아닌 경우
            if not isinstance(stock_info, dict):
                self.logger.warning(f"⚠️ 예상치 못한 데이터 타입: {type(stock_info)}")
                return StockData(
                    symbol='UNKNOWN',
                    name='알 수 없음',
                    current_price=0.0,
                    change_rate=0.0,
                    volume=0,
                    trading_value=0.0,
                    market_cap=0.0,
                    shares_outstanding=0,
                    high_52w=0.0,
                    low_52w=0.0
                )
            
            # Dictionary 처리 - None 체크 강화
            symbol = str(stock_info.get('symbol', 'UNKNOWN')) if stock_info.get('symbol') is not None else 'UNKNOWN'
            name = str(stock_info.get('name', f'종목{symbol}')) if stock_info.get('name') is not None else f'종목{symbol}'
            
            # 숫자 데이터 안전하게 파싱 (None 체크 포함)
            current_price = self._safe_float_parse(stock_info.get('current_price'), 0.0)
            change_rate = self._safe_float_parse(stock_info.get('change_rate'), 0.0)
            volume = self._safe_int_parse(stock_info.get('volume'), 0)
            trading_value = self._safe_float_parse(stock_info.get('trading_value'), 0.0)
            market_cap = self._safe_float_parse(stock_info.get('market_cap'), 0.0)
            high_52w = self._safe_float_parse(stock_info.get('high_52w'), 0.0)
            low_52w = self._safe_float_parse(stock_info.get('low_52w'), 0.0)
            
            # 52주 고저가 추정
            if high_52w <= 0 and current_price > 0:
                high_52w = current_price * 1.5
            if low_52w <= 0 and current_price > 0:
                low_52w = current_price * 0.7
            
            # shares_outstanding 계산 (None 체크)
            shares_outstanding = 0
            if current_price > 0 and market_cap > 0:
                try:
                    shares_outstanding = int(market_cap * 100000000 / current_price)
                except (ZeroDivisionError, TypeError):
                    shares_outstanding = 0
            
            # PER, PBR 등 처리 (None 안전) - math.isnan 사용
            pe_ratio = stock_info.get('pe_ratio')
            pbr = stock_info.get('pbr')
            eps = stock_info.get('eps')
            bps = stock_info.get('bps')
            
            # None이나 NaN, 0 이하 값 처리
            def is_valid_number(val):
                if val is None:
                    return False
                try:
                    if isinstance(val, (int, float)):
                        return not (math.isnan(val) or math.isinf(val) or val <= 0)
                    else:
                        float_val = float(val)
                        return not (math.isnan(float_val) or math.isinf(float_val) or float_val <= 0)
                except (ValueError, TypeError):
                    return False
            
            if not is_valid_number(pe_ratio):
                pe_ratio = None
            if not is_valid_number(pbr):
                pbr = None
            if not is_valid_number(eps):
                eps = None
            if not is_valid_number(bps):
                bps = None
            
            stock_data = StockData(
                symbol=symbol,
                name=name,
                current_price=current_price,
                change_rate=change_rate,
                volume=volume,
                trading_value=trading_value,
                market_cap=market_cap,
                shares_outstanding=shares_outstanding,
                high_52w=high_52w,
                low_52w=low_52w,
                pe_ratio=pe_ratio,
                pbr=pbr,
                eps=eps,
                bps=bps,
                sector=stock_info.get('sector', '기타') if stock_info.get('sector') is not None else '기타'
            )
            
            self.logger.debug(f"✅ {symbol} StockData 생성 완료")
            return stock_data
            
        except Exception as e:
            self.logger.warning(f"⚠️ StockData 생성 실패: {e}")
            self.logger.debug(f"📄 오류 데이터: {stock_info}")
            
            # 최후의 안전장치
            try:
                symbol = 'UNKNOWN'
                name = '알 수 없음'
                
                if isinstance(stock_info, dict) and stock_info.get('symbol'):
                    symbol = str(stock_info.get('symbol', 'UNKNOWN'))
                    name = str(stock_info.get('name', f'종목{symbol}'))
                elif isinstance(stock_info, str):
                    symbol = stock_info
                    name = f'종목{symbol}'
                elif isinstance(stock_info, tuple) and len(stock_info) >= 2:
                    symbol, name = str(stock_info[0]), str(stock_info[1])
                    
            except:
                symbol = 'UNKNOWN'
                name = '알 수 없음'
            
            return StockData(
                symbol=symbol,
                name=name,
                current_price=0.0,
                change_rate=0.0,
                volume=0,
                trading_value=0.0,
                market_cap=0.0,
                shares_outstanding=0,
                high_52w=0.0,
                low_52w=0.0
            )

    def _cache_stock_names(self, stock_list):
        """종목명 캐시 생성"""
        try:
            if not hasattr(self, '_cached_stock_names'):
                self._cached_stock_names = {}
            
            for symbol, name in stock_list:
                if symbol and name and not name.startswith('종목'):
                    self._cached_stock_names[symbol] = name
            
            self.logger.debug(f"✅ {len(self._cached_stock_names)}개 종목명 캐시 생성")
        except Exception as e:
            self.logger.debug(f"⚠️ 종목명 캐시 생성 실패: {e}")
    async def get_filtered_stocks_pykrx(self, limit: int = 50, use_cache: bool = True) -> List[Tuple[str, str]]:
        """pykrx를 활용한 효율적인 종목 필터링 - 종목명 캐시 추가"""
        try:
            self.logger.info(f"🔍 pykrx 기반 종목 필터링 시작 (목표: {limit}개)")
            
            # 현재 시간 체크
            from datetime import datetime, time, timedelta
            now = datetime.now()
            market_open = time(9, 0)
            market_close = time(15, 30)
            is_market_time = market_open <= now.time() <= market_close
            is_weekday = now.weekday() < 5
            
            # 캐시 확인
            if use_cache:
                cached_stocks = await self._get_cached_filtered_stocks(limit)
                if cached_stocks:
                    self.logger.info(f"✅ 캐시된 필터링 결과 사용: {len(cached_stocks)}개 종목")
                    # 캐시된 종목명도 저장
                    self._cache_stock_names(cached_stocks)
                    return cached_stocks
            
            # pykrx 데이터 조회
            from pykrx import stock
            import pandas as pd
            
            # 조회 날짜 결정
            if not is_weekday or (is_weekday and now.time() < market_open):
                date = now
                while date.weekday() >= 5:
                    date = date - timedelta(days=1)
                if is_weekday and now.time() < market_open:
                    date = date - timedelta(days=1)
                date_str = date.strftime("%Y%m%d")
                self.logger.info(f"📅 전 거래일 데이터 사용: {date_str}")
            else:
                date_str = now.strftime("%Y%m%d")
                self.logger.info(f"📅 당일 데이터 사용: {date_str}")
            
            # 필터링 조건
            min_price = self.config.trading.MIN_PRICE
            max_price = self.config.trading.MAX_PRICE
            min_volume = self.config.trading.MIN_VOLUME
            min_market_cap = self.config.trading.MIN_MARKET_CAP
            
            if not is_market_time:
                min_volume = max(100, min_volume // 10)
                self.logger.info(f"📊 장 시간 외로 거래량 조건 완화: {min_volume:,}주")
            
            # 초기화
            all_filtered_stocks = []
            
            # KOSPI와 KOSDAQ 각각 처리
            for market in ["KOSPI", "KOSDAQ"]:
                try:
                    self.logger.info(f"📊 {market} 시장 필터링 중...")
                    
                    # 데이터 조회 시도
                    try:
                        df = stock.get_market_cap(date_str, market=market)
                    except Exception as e:
                        self.logger.warning(f"⚠️ {market} {date_str} 데이터 조회 실패, 이전 날짜 시도: {e}")
                        # 이전 날짜들 시도
                        for days_back in range(1, 8):
                            try:
                                fallback_date = (datetime.strptime(date_str, "%Y%m%d") - timedelta(days=days_back)).strftime("%Y%m%d")
                                df = stock.get_market_cap(fallback_date, market=market)
                                self.logger.info(f"✅ {market} {fallback_date} 데이터로 대체 성공")
                                break
                            except:
                                continue
                        else:
                            self.logger.error(f"❌ {market} 모든 날짜 시도 실패")
                            continue
                    
                    # 인덱스를 컬럼으로 변환 (copy 생성)
                    df = df.reset_index().copy()
                    df.rename(columns={'티커': '종목코드'}, inplace=True)
                    
                    # 종목명 추가
                    df["종목명"] = df["종목코드"].apply(lambda x: stock.get_market_ticker_name(x))
                    
                    # 데이터 타입 변환 및 NaN 처리
                    df["종가"] = pd.to_numeric(df["종가"], errors='coerce').fillna(0)
                    df["거래량"] = pd.to_numeric(df["거래량"], errors='coerce').fillna(0)
                    df["시가총액"] = pd.to_numeric(df["시가총액"], errors='coerce').fillna(0)
                    
                    # 시가총액 단위 변환
                    df["시가총액(억원)"] = df["시가총액"] // 100000000
                    
                    # 1차 필터링 (copy() 사용으로 경고 방지)
                    filtered_df = df[
                        (df["종가"] >= min_price) & 
                        (df["종가"] <= max_price) & 
                        (df["거래량"] >= min_volume) & 
                        (df["시가총액(억원)"] >= min_market_cap) &
                        (df["종목명"].notna()) &
                        (df["종가"] > 0) &
                        (~df["종목명"].str.contains('관리|정리매매|투자주의|투자경고|스팩|SPAC|지주회사', na=False))
                    ].copy()
                    
                    # 거래대금 조건 (copy된 DataFrame에서 안전하게 수정)
                    min_trading_value = 100 if is_market_time else 50
                    filtered_df.loc[:, "거래대금(백만원)"] = (filtered_df["종가"] * filtered_df["거래량"]) / 1000000
                    filtered_df = filtered_df[filtered_df["거래대금(백만원)"] >= min_trading_value].copy()
                    
                    # 결과를 튜플 리스트로 변환
                    market_stocks = [(row["종목코드"], row["종목명"]) for _, row in filtered_df.iterrows()]
                    all_filtered_stocks.extend(market_stocks)
                    
                    self.logger.info(f"✅ {market} 필터링 완료: {len(market_stocks)}개 종목")
                    
                    # 처음 3개 종목 로그 출력
                    for i, (code, name) in enumerate(market_stocks[:3]):
                        try:
                            row_data = filtered_df[filtered_df["종목코드"] == code].iloc[0]
                            price = row_data["종가"]
                            volume = row_data["거래량"]
                            market_cap = row_data["시가총액(억원)"]
                            trading_value = row_data["거래대금(백만원)"]
                            self.logger.info(f"   📋 {market} 예시 {i+1}: {code} ({name})")
                            self.logger.info(f"       💰 가격: {price:,.0f}원, 📊 거래량: {volume:,}주")
                            self.logger.info(f"       🏢 시총: {market_cap:.0f}억원, 💵 거래대금: {trading_value:.0f}백만원")
                        except Exception as e:
                            self.logger.debug(f"⚠️ {code} 로그 출력 실패: {e}")
                    
                except Exception as e:
                    self.logger.warning(f"⚠️ {market} 시장 필터링 실패: {e}")
                    continue
            
            # 결과 제한 및 정렬
            if len(all_filtered_stocks) > limit:
                try:
                    # 시가총액 기준으로 정렬
                    sorted_stocks = []
                    for symbol, name in all_filtered_stocks:
                        try:
                            cap_info = stock.get_market_cap(date_str, market="ALL")
                            if symbol in cap_info.index:
                                market_cap = cap_info.loc[symbol, '시가총액'] / 100000000
                                sorted_stocks.append((symbol, name, market_cap))
                            else:
                                sorted_stocks.append((symbol, name, 0))
                        except:
                            sorted_stocks.append((symbol, name, 0))
                    
                    sorted_stocks.sort(key=lambda x: x[2], reverse=True)
                    all_filtered_stocks = [(s[0], s[1]) for s in sorted_stocks[:limit]]
                    
                except Exception:
                    all_filtered_stocks = all_filtered_stocks[:limit]
            
            # 종목명 캐시 생성 및 결과 캐시에 저장
            if all_filtered_stocks:
                # 종목명 캐시 생성
                self._cache_stock_names(all_filtered_stocks)
                # 결과 캐시에 저장
                await self._cache_filtered_stocks(all_filtered_stocks)
                self.logger.info(f"💾 필터링 결과 및 종목명 캐시 저장 완료")
            
            self.logger.info(f"✅ pykrx 필터링 완료: 총 {len(all_filtered_stocks)}개 종목 선정")
            
            if len(all_filtered_stocks) == 0:
                self.logger.warning("⚠️ 필터링 조건을 만족하는 종목이 없습니다.")
                fallback_stocks = await self._get_major_stocks_as_fallback(limit)
                # 대체 종목의 종목명도 캐시
                self._cache_stock_names(fallback_stocks)
                return fallback_stocks
            
            return all_filtered_stocks
            
        except ImportError:
            self.logger.error("❌ pykrx 라이브러리가 설치되지 않았습니다.")
            return await self.get_filtered_stocks(limit, use_cache)
        except Exception as e:
            self.logger.error(f"❌ pykrx 필터링 실패: {e}")
            return await self.get_filtered_stocks(limit, use_cache)
    def _cache_stock_names(self, stock_list):
        """종목명 캐시 생성"""
        try:
            if not hasattr(self, '_cached_stock_names'):
                self._cached_stock_names = {}
            
            for symbol, name in stock_list:
                if symbol and name and not name.startswith('종목') and name.strip():
                    self._cached_stock_names[symbol] = name.strip()
            
            self.logger.debug(f"✅ {len(self._cached_stock_names)}개 종목명 캐시 생성")
        except Exception as e:
            self.logger.debug(f"⚠️ 종목명 캐시 생성 실패: {e}")
    
    async def get_market_summary(self) -> Dict:
        """시장 전체 요약 정보"""
        try:
            self.logger.info("📈 시장 요약 정보 조회 중...")
            
            if not await self._check_token_validity():
                raise Exception("토큰이 유효하지 않습니다.")
            
            # 주요 지수 조회 (KOSPI, KOSDAQ)
            indices = {
                "0001": "KOSPI",
                "1001": "KOSDAQ"
            }
            
            market_data = {}
            
            for code, name in indices.items():
                try:
                    url = f"{self.base_url}/uapi/domestic-stock/v1/quotations/inquire-index-price"
                    
                    params = {
                        "FID_COND_MRKT_DIV_CODE": "U",
                        "FID_INPUT_ISCD": code
                    }
                    
                    headers = {
                        "tr_id": "FHKUP03500100",
                        "custtype": "P"
                    }
                    headers.update(self.session.headers)
                    
                    async with self.session.get(url, params=params, headers=headers) as response:
                        if response.status == 200:
                            data = await response.json()
                            index_info = self._parse_index_info(data, name)
                            if index_info:
                                market_data[name] = index_info
                        elif response.status != 200:
                            error_text = await response.text()
                            self.logger.warning(f"⚠️ {name} 지수 조회 실패: {response.status}, {error_text}")
                        
                        await asyncio.sleep(0.1)  # API 제한 방지
                        
                except Exception as e:
                    self.logger.warning(f"⚠️ {name} 지수 조회 실패: {e}")
                    continue
            
            if len(market_data) == 0:
                raise Exception("시장 지수 정보를 조회할 수 없습니다.")
            
            self.logger.info(f"✅ 시장 요약 정보 조회 완료: {len(market_data)}개 지수")
            return market_data
            
        except Exception as e:
            self.logger.error(f"❌ 시장 요약 정보 조회 실패: {e}")
            raise e
    
    def _parse_index_info(self, data: Dict, index_name: str) -> Optional[Dict]:
        """지수 정보 파싱"""
        try:
            rt_cd = data.get('rt_cd', '')
            if rt_cd != '0':
                msg = data.get('msg1', 'Unknown error')
                self.logger.debug(f"⚠️ {index_name} 지수 API 응답 오류: {rt_cd} - {msg}")
                return None
            
            output = data.get('output', {})
            if not output:
                return None
            
            current_value = self._safe_float_parse(output.get('bstp_nmix_prpr', '0'))
            change_rate = self._safe_float_parse(output.get('bstp_nmix_prdy_ctrt', '0'))
            change_value = self._safe_float_parse(output.get('bstp_nmix_prdy_vrss', '0'))
            
            if current_value <= 0:
                return None
            
            return {
                "name": index_name,
                "current_value": current_value,
                "change_rate": change_rate,
                "change_value": change_value,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.debug(f"⚠️ {index_name} 지수 파싱 오류: {e}")
            return None